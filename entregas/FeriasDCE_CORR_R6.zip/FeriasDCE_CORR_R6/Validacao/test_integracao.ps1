﻿$ErrorActionPreference='Stop'
. "$PSScriptRoot/test_regressao.ps1"
$checks=[Collections.Generic.List[string]]::new()
function Check($Condition,[string]$Name){if(-not $Condition){throw "FALHOU: $Name"};$checks.Add($Name)}
Reset-Fixture
$r=New-Record;$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-01-01';$r.fixo_fim='2027-01-15'
$r|Add-Member NoteProperty fixos_adicionais @([pscustomobject]@{inicio='2027-03-01';fim='2027-03-15'},[pscustomobject]@{inicio='2028-01-01';fim='2028-01-15'})
$script:Records=@($r)
Check ((Get-ContagemInstitucionalAprovadaMes 2028 1) -eq 0.5) 'Todas as parcelas, inclusive terceira parcela e passagem de ano, entram no institucional'
$r.fixos_adicionais[0].inicio='2027-04-01';$r.fixos_adicionais[0].fim='2027-04-15'
Check ((Get-ContagemInstitucionalAprovadaMes 2027 3) -eq 0 -and (Get-ContagemInstitucionalAprovadaMes 2027 4) -eq 0.5) 'Mudanca de adicional invalida peso memoizado mesmo com principal igual'
$antes=$r|ConvertTo-Json -Depth 12
Save-EstadoAntesImportacaoFixa $r
$manual=@(Get-FixasAdicionais $r).Count
$r.fixos_adicionais+=,[pscustomobject]@{inicio='2027-06-01';fim='2027-06-15';arquivo='FICTICIO.xlsx';importado_em='2026-10-20'}
$r.origem_planejamento='PROGRAMACAO_ANTERIOR_IMPORTADA';$r.fixo_importado_em='2026-10-20'
Save-EstadoAntesImportacaoFixa $r
Reset-FixasImportadas
Check ((Get-FixasAdicionais $r).Count -eq $manual -and $r.ferias_bloqueadas -and $r.origem_planejamento -eq 'ATUAL' -and $r.fixo_inicio -eq '2027-01-01') 'Reversao de importacao restaura principal e todas as parcelas manuais anteriores; snapshot capturado uma vez'
Check (@($r.pre_import_fixos_adicionais).Count -eq 0) 'Snapshot de parcelas e limpo depois da reversao'
# Reject invalid backup filenames and sort across prefixes/milliseconds.
$script:Restored=''
function Get-ChildItem {param($LiteralPath,$Filter,[switch]$File,$ErrorAction)@(
 [pscustomobject]@{Name='ANTES_RESET_ZZZ_20269999_999999_000.json';FullName='/invalido.json'},
 [pscustomobject]@{Name='ANTES_RESET_ZZZ_20261020_120000_001.json';FullName='/anterior.json'},
 [pscustomobject]@{Name='ANTES_RESET_AAA_20261020_120000_002.json';FullName='/mais_recente.json'})}
Restaurar-UltimoPreReset
Remove-Item Function:Get-ChildItem
Check ($script:Restored -eq '/mais_recente.json') 'Selecao de backup ignora timestamp invalido e respeita milissegundos independentemente do prefixo'
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-04-01' 15;$r.opcao1.tipo='15+15 DIAS';$r.opcao1.inicio2='2027-08-01';$r.opcao1.fim2='2027-08-15'
$r2=New-Record 2 TESTE2;$r2.opcao1=New-Common '2027-04-16' 15;$r2.opcao1.tipo='15+15 DIAS';$r2.opcao1.inicio2='2027-09-01';$r2.opcao1.fim2='2027-09-15'
$script:Records=@($r,$r2)
$f=[pscustomobject]@{Ano=2027;Mes=4;Situacao='TODAS AS LINHAS';Busca='';Sobreposicao=$true}
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 0) 'Duas ferias no mesmo mes sem datas coincidentes nao viram sobreposicao'
$r2.opcao1.inicio1='2027-04-15';$r2.opcao1.fim1='2027-04-29'
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 1) 'Coincidencia no dia de fronteira conta como sobreposicao'
$r2.matricula=$r.matricula
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 0) 'Dois registros da mesma matricula nao simulam dois profissionais simultaneos'
$f.Sobreposicao=$false;$f.Situacao='COM FÉRIAS FIXAS'
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 0) 'Filtro de fixas exclui solicitacoes comuns'
$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-04-01';$r.fixo_fim='2027-04-15'
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 1) 'Filtro de fixas inclui compromisso fixo no mes escolhido'
$f.Situacao='SEM LIMITE';$script:Config.total_enfermeiros_planejamento=0
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 1) 'SEM LIMITE usa capacidade institucional ausente, coerente com politica atual'
$script:Config.total_enfermeiros_planejamento=189
Check ((Get-PlanejamentoViewModel $f).Linhas.Count -eq 0) 'SEM LIMITE exclui mes com capacidade institucional configurada'
# Policy acceptance must still work after staging validation.
Reset-Fixture
$numTotalEnf=[pscustomobject]@{Value=200};$numPctRestrito=[pscustomobject]@{Value=10}
$script:chkMesRestrito=@();$script:numLimiteEspecialMes=@()
foreach($month in 1..12){$script:chkMesRestrito+=,[pscustomobject]@{Checked=($month -eq 1)};$script:numLimiteEspecialMes+=,[pscustomobject]@{Value=$(if($month -eq 1){12}else{0})}}
function Refresh-PoliticaMensalInfo {};function Refresh-LimiteInstitucionalResumo {};function Request-DashboardRefresh {};function Request-PlanejamentoRefresh {}
& (Handler '' '$btnSalvarPoliticaMensal.add_Click(')
Check ($script:AuditSaves -eq 1 -and $script:Config.total_enfermeiros_planejamento -eq 200 -and $script:Config.limites_especiais_mensais['1'] -eq 12) 'Politica valida aplica todos os campos e salva uma vez'
# Restore the real institutional renderer after the policy stub.
$fn=$ast.EndBlock.Statements|Where-Object {$_.Name -eq 'Refresh-LimiteInstitucionalResumo'}
. ([scriptblock]::Create($fn.Extent.Text))
# Actual re-render of all twelve cells, with nonpositive limits avoiding unsupported Linux GDI.
Reset-Fixture
$script:Config.total_enfermeiros_planejamento=0
$script:cmbPlanejAno=[pscustomobject]@{SelectedItem=2027};$script:lblLimiteInstitucional=[pscustomobject]@{Text=''}
$script:tabsPrincipal=[pscustomobject]@{SelectedTab='plano'};$script:tabPlanejamentoPrincipal='plano'
$script:PlanejAsync=@{Ready=@{Key='antigo'}}
$rows=[pscustomobject]@{};$rows|Add-Member ScriptMethod Clear {}
$script:gridPlanejSetor=[pscustomobject]@{Rows=$rows;Enabled=$true};$script:lblPlanejResumo=[pscustomobject]@{Text=''}
$cells=@{};$model=[pscustomobject]@{Meses=@{}}
foreach($m in 1..12){$cells['li'+$m]=[pscustomobject]@{Value='Antigo';ToolTipText='Antigo';Style=[pscustomobject]@{BackColor=$null}};$model.Meses[$m]=[pscustomobject]@{qtd=0;real=0;limite=0;detalhes=@{tooltip=''}}}
$script:gridLimiteInstitucional=[pscustomobject]@{Enabled=$true;Rows=@([pscustomobject]@{Cells=@($cells.Values)})}
$script:InstitutionalResumoCacheKey='2027|0|0|sintetico'
Set-PlanejamentoUiFalha 'falha'
$script:gridLimiteInstitucional.Rows[0].Cells=$cells
Refresh-LimiteInstitucionalResumo $model
Check (@($cells.Values|Where-Object {$_.Value -like 'REAL:*'}).Count -eq 12) 'Apos falha, renderizador real preenche as 12 celulas novamente com a mesma base'
# FR-only approval and pending choice never masquerade as confirmed.
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-01-01';$r.opcao2=New-Common '2027-02-01';$r.opcao2.fr_inicio='2027-08-01';$r.opcao2.fr_fim='2027-08-20';$r.fr_opcao_aprovada=2
Check (@(Get-BlocosConfirmadosRegistro $r).Count -eq 1 -and (Get-BlocosConfirmadosRegistro $r)[0].inicio.Month -eq 8) 'Somente FR aprovada nao inclui comum pendente no mapa definido'
$r.fr_opcao_aprovada=0
Check (@(Get-BlocosConfirmadosRegistro $r).Count -eq 0) 'Opcoes pendentes nao entram como compromisso aprovado'
$r.opcao_aprovada=1;$before=$r|ConvertTo-Json -Depth 12
$p=@(Get-PendenciasSemanticasBase @($r))
Check ($p.Count -eq 0 -and ($r|ConvertTo-Json -Depth 12) -eq $before) 'Diagnostico aceita aprovacao valida e nao altera o registro'
# A valid acquisition correction must remain available.
$r.ferias_bloqueadas=$true;$r.fixo_inicio='2028-01-01';$r.fixo_fim='2028-01-15';$r.opcao_aprovada=0;$r.opcao1=New-EmptyOptionObject;$r.opcao2=New-EmptyOptionObject
$script:Records=@($r);$id=1;$antIni=$r.aquisitivo_inicio;$antFim=$r.aquisitivo_fim
$ini=[pscustomobject]@{Value=[datetime]::new(2027,1,1)};$fim=[pscustomobject]@{Value=[datetime]::new(2027,12,31)};$mot=[pscustomobject]@{Text='Teste sintetico'}
$dlg=[pscustomobject]@{Tag=$null;DialogResult=[Windows.Forms.DialogResult]::None};$dlg|Add-Member ScriptMethod Close {}
& (Handler 'Corrigir-PeriodoSelecionado' '$ok.add_Click(')
Check ($null -ne $dlg.Tag -and $dlg.Tag.fim -eq '2027-12-31') 'Correcao valida do aquisitivo continua permitida quando fixa ocorre depois do novo fim'
Reset-Fixture
$r=New-Record;$r.opcao_aprovada=1
# Generate the REAL HTML report; mock only external browser start. Contains exclusively synthetic data.
function Start-Process {param($FilePath)$script:Generated=$FilePath}
$r.opcao1=New-Common '2027-01-17';$r.opcao1.fr_inicio='2027-02-16';$r.opcao1.fr_fim='2027-03-07';$r.fr_opcao_aprovada=1
$script:Records=@($r);$script:Generated=''
Show-RelatorioAceitesEnfermagem
if(-not [IO.File]::Exists($script:Generated)){throw [Windows.Forms.MessageBox]::Last}
Check ([IO.File]::Exists($script:Generated)) 'Relatorio HTML completo gerado pelo codigo real'
$report=[IO.File]::ReadAllText($script:Generated)
$match=[regex]::Match($report,'<script id="dados" type="application/json">(.*?)</script>','Singleline')
$nominais=@($match.Groups[1].Value|ConvertFrom-Json)
$fev=@($nominais|Where-Object mes -eq 'fev/2027')
Check ($fev.Count -eq 2 -and @($fev|Where-Object {$_.peso_institucional -ne 1}).Count -eq 0) 'HTML leva contribuicao institucional compartilhada para comum e FR em fevereiro'
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'RELATORIO_SINTETICO.html'),$report)
$checks|Set-Content "$PSScriptRoot/RESULTADOS_INTEGRACAO.txt" -Encoding utf8
$checks
"TOTAL: $($checks.Count) verificacoes de integracao aprovadas."
