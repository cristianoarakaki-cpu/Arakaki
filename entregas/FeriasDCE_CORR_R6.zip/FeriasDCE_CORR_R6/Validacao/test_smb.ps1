﻿$ErrorActionPreference='Stop'
$source=(Join-Path (Split-Path $PSScriptRoot -Parent) 'FeriasDCE.ps1')
$t=$null;$e=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($source,[ref]$t,[ref]$e)
if($e.Count){throw ($e|Out-String)}
$names=@('Get-TextSha256','Assert-DatabaseStructure','Assert-ValidJsonFile','Invoke-DatabaseFileReplace','Invoke-DatabaseAtomicRename','Invoke-DatabaseCompatibleReplace','Commit-DatabaseTempFile')
$defs=@{}
foreach($name in $names){
 $f=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 $defs[$name]=$f.Extent.Text
 . ([scriptblock]::Create($defs[$name]))
}
function Write-DiagLog {param($Message,$Level,$ErrorRecord)}
$root=Join-Path /tmp ('ferias-smb-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($root)
$old='{"configuracoes":{},"registros":[],"revisao_dados":1}'
$new='{"configuracoes":{},"registros":[],"revisao_dados":2}'
$external='{"configuracoes":{},"registros":[],"revisao_dados":7}'
$script:checks=New-Object 'System.Collections.Generic.List[string]'
function Paths([string]$name){
 $p=Join-Path $root $name;[void][IO.Directory]::CreateDirectory($p)
 $script:dest=Join-Path $p 'base.json';$script:temp=Join-Path $p 'nova.tmp'
 [IO.File]::WriteAllText($dest,$old);[IO.File]::WriteAllText($temp,$new)
}
try {
 Paths 'normal';[void](Commit-DatabaseTempFile $temp $dest)
 if([IO.File]::ReadAllText($dest) -ne $new){throw 'Commit normal'}
 $checks.Add('File.Replace normal preservado e validado')
 Paths 'json-invalido';[IO.File]::WriteAllText($temp,'invalido')
 $fail=$false;try{Commit-DatabaseTempFile $temp $dest|Out-Null}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $old){throw 'JSON invalido'}
 $checks.Add('JSON invalido bloqueado antes de tocar na base')
 # Injetar somente os adaptadores de IO: nao e um teste de Win32/SMB.
 function Invoke-DatabaseFileReplace {param($Source,$Destination,$Backup) throw [UnauthorizedAccessException]::new('TESTE acesso negado')}
 function Invoke-DatabaseAtomicRename {param($Source,$Destination,$ExpectedOldHash) [IO.File]::Move($Source,$Destination,$true)}
 Paths 'alternativa';[void](Commit-DatabaseTempFile $temp $dest)
 if([IO.File]::ReadAllText($dest) -ne $new){throw 'Alternativa nao gravou'}
 $checks.Add('Fallback apos acesso negado, com backup e validacao posterior (adaptador simulado)')
 function Invoke-DatabaseAtomicRename {param($Source,$Destination,$ExpectedOldHash) throw [UnauthorizedAccessException]::new('TESTE rename negado')}
 Paths 'negado';$fail=$false;try{Commit-DatabaseTempFile $temp $dest|Out-Null}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $old){throw 'Falha de rename alterou base'}
 $backups=@(Get-ChildItem -LiteralPath ([IO.Path]::GetDirectoryName($dest)) -Filter '*.replacebak.*')
 if($backups.Count -ne 1 -or [IO.File]::ReadAllText($backups[0].FullName) -ne $old){throw 'Backup de negacao'}
 $checks.Add('Rename recusado preserva destino e backup')
 function Invoke-DatabaseFileReplace {param($Source,$Destination,$Backup) [IO.File]::WriteAllText($Destination,$external);throw [UnauthorizedAccessException]::new('TESTE destino mudou')}
 function Invoke-DatabaseAtomicRename {param($Source,$Destination,$ExpectedOldHash) throw 'NAO DEVERIA SER CHAMADO'}
 Paths 'alteracao-externa';$fail=$false;try{Commit-DatabaseTempFile $temp $dest|Out-Null}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $external){throw 'Alteracao externa nao protegida'}
 $checks.Add('Estado alterado apos Replace recusado impede fallback')
 function Invoke-DatabaseFileReplace {param($Source,$Destination,$Backup) throw [UnauthorizedAccessException]::new('TESTE negado')}
 Paths 'backup-diverge';$bk=Join-Path ([IO.Path]::GetDirectoryName($dest)) 'backup-teste.json';[IO.File]::WriteAllText($bk,$external)
 $fail=$false;try{Invoke-DatabaseCompatibleReplace $temp $dest $bk}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $old){throw 'Backup divergente'}
 $checks.Add('Backup divergente impede a alternativa')
 $script:renameCalls=0
 function Invoke-DatabaseAtomicRename {
  param($Source,$Destination,$ExpectedOldHash)
  [IO.File]::Move($Source,$Destination,$true)
  $script:renameCalls++
  if($script:renameCalls -eq 1){[IO.File]::WriteAllText($Destination,'CORRUPCAO_SINTETICA')}
 }
 Paths 'rollback';$fail=$false;try{Commit-DatabaseTempFile $temp $dest|Out-Null}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $old -or $renameCalls -ne 2){throw 'Rollback da alternativa'}
 $checks.Add('Falha na verificacao posterior restaura backup pelo mesmo caminho alternativo (simulado)')
 Paths 'pasta-diferente';$other=Join-Path $root 'externo.tmp';[IO.File]::WriteAllText($other,$new)
 $fail=$false;try{Commit-DatabaseTempFile $other $dest|Out-Null}catch{$fail=$true}
 if(-not $fail -or [IO.File]::ReadAllText($dest) -ne $old){throw 'Pasta diferente'}
 $checks.Add('Temporario fora da pasta de destino recusado')
 $checks | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'RESULTADOS_PERSISTENCIA.txt') -Encoding UTF8
 Write-Output ($checks.Count.ToString()+' cenarios passaram. Parser sem erros. Win32/ACL/SMB reais nao executados.')
} finally {Remove-Item -LiteralPath $root -Force -Recurse}
