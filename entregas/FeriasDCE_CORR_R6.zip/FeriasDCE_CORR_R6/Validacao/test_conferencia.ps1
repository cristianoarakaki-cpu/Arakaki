﻿$ErrorActionPreference='Stop'
. "$PSScriptRoot/test_regressao.ps1"
$fn=$ast.EndBlock.Statements|Where-Object Name -eq 'Show-RelatorioConferenciaOpcoes'
$statements=$fn.Body.EndBlock.Statements
$refresh=$statements|Where-Object {$_.Extent.Text.StartsWith('$refresh=')}|Select-Object -First 1
$try=$refresh.Find({param($n)$n -is [Management.Automation.Language.TryStatementAst]},$true)
$body=@();foreach($st in $try.Body.Statements){if($st.Extent.Text.StartsWith('$store.Shown=')){break};$body+=$st.Extent.Text}
if($body.Count -lt 15){throw 'Trecho de conferencia nao extraido'}
$bodyBlock=[scriptblock]::Create(($body -join "`n")+"`nreturn [pscustomobject]@{Monthly=`$monthly;Details=`$dt}")
foreach($assignment in @('$monthHit=','$dateBR=')){
 $statement=$statements|Where-Object {$_.Extent.Text.StartsWith($assignment)}|Select-Object -First 1
 if(-not $statement){throw 'Helper de datas ausente'}
 . ([scriptblock]::Create($statement.Extent.Text))
}
$select=[pscustomobject]@{SelectedIndex=0};$year=[pscustomobject]@{SelectedItem=2027};$month=[pscustomobject]@{SelectedIndex=0};$modality=[pscustomobject]@{SelectedItem='Todas'};$search=[pscustomobject]@{Text=''};$sector=[pscustomobject]@{SelectedItem='Todos'};$period=[pscustomobject]@{SelectedItem='Todos'};$modo=[pscustomobject]@{SelectedItem='Programacao aprovada'}
$getChosen={@('Modalidade','Datas','Inicio fixa','Fim fixa')};$fields=@{Modalidade='modalidade';Datas='mes_periodo';'Inicio fixa'='fixo_inicio';'Fim fixa'='fixo_fim'}
$pesoInstitucionalRelatorio=(Get-Command Get-PesoBlocoInstitucionalMes).ScriptBlock;$limiteInstitucionalRelatorio=(Get-Command Get-LimiteInstitucionalMes).ScriptBlock
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-01-17';$r.opcao1.fr_inicio='2027-02-16';$r.opcao1.fr_fim='2027-03-07';$r.opcao_aprovada=1;$r.fr_opcao_aprovada=1;$script:Records=@($r)
$store=[pscustomobject]@{Records=@($r)}
$m=& $bodyBlock
if(($m.Monthly.Rows|Where-Object Mes -eq 'Fev')['Equivalentes'] -ne '1'){throw 'Conferencia ainda duplica comum/FR'}
$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-01-01';$r.fixo_fim='2027-01-15';$r|Add-Member NoteProperty fixos_adicionais @([pscustomobject]@{inicio='2027-03-01';fim='2027-03-15'})
$month.SelectedIndex=3
$m=& $bodyBlock
if(($m.Monthly.Rows|Where-Object Mes -eq 'Mar')['Equivalentes'] -ne '0,5'){throw ('Conferencia omitiu fixa adicional: '+($m.Monthly|Out-String)+($m.Details|Out-String))}
if($m.Details.Rows.Count -ne 1 -or $m.Details.Rows[0]['Datas'] -ne '01/03/2027 a 15/03/2027' -or $m.Details.Rows[0]['Inicio fixa'] -ne '01/03/2027'){throw 'Detalhe nominal nao corresponde a parcela do mes'}
'Conferencia: comum/FR=1 no mes; adicional fixo=0,5; detalhe nominal e datas do mes correspondem a parcela adicional.'|Tee-Object -FilePath "$PSScriptRoot/RESULTADOS_CONFERENCIA.txt"
