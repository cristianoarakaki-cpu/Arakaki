﻿$ErrorActionPreference='Stop'
$t=$null;$e=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path (Split-Path $PSScriptRoot -Parent) 'FeriasDCE.ps1'),[ref]$t,[ref]$e)
if($e.Count){throw ($e|Out-String)}
foreach($f in $ast.EndBlock.Statements){if($f -is [Management.Automation.Language.FunctionDefinitionAst]){. ([scriptblock]::Create($f.Extent.Text))}}
function Write-DiagLog {param($Message,$Level,$ErrorRecord)}
$script:Requests=@();$script:SnapshotKey='inicial';$script:Timers=@()
function Get-PlanejamentoSnapshot {[pscustomobject]@{Key=$script:SnapshotKey;Json='teste'}}
function Request-PlanejamentoComputation($Snapshot){$script:Requests+=,$Snapshot.Key}
function New-Object {
 param([string]$TypeName)
 if($TypeName -ne 'Windows.Forms.Timer'){throw "Tipo inesperado: $TypeName"}
 $timer=[pscustomobject]@{Interval=0;Started=$false;Disposed=$false;Callback=$null}
 $timer|Add-Member ScriptMethod add_Tick {param($callback)$this.Callback=$callback}
 $timer|Add-Member ScriptMethod Start {$this.Started=$true}
 $timer|Add-Member ScriptMethod Stop {$this.Started=$false}
 $timer|Add-Member ScriptMethod Dispose {$this.Disposed=$true}
 $timer|Add-Member ScriptMethod Fire {. $this.Callback}
 $script:Timers+=,$timer
 return $timer
}
$script:cmbPlanejAno=[pscustomobject]@{SelectedItem=2027}
$script:PlanejWarmupClosed=$false;$script:PlanejBootSyncPending=$true;$script:PlanejAsync=$null
Request-PlanejamentoWarmup;Start-PlanejamentoWarmup
if($script:Timers.Count -or $script:Requests.Count){throw 'Preparo ocorreu antes da sincronizacao'}
$script:PlanejBootSyncPending=$false
Request-PlanejamentoWarmup;Request-PlanejamentoWarmup
if($script:Timers.Count -ne 1 -or -not $script:Timers[0].Started){throw 'Agendamento duplicado/ausente'}
$script:Timers[0].Fire()
if($script:Requests.Count -ne 1 -or -not $script:Timers[0].Disposed -or $null -ne $script:PlanejWarmupTimer){throw 'Tick nao iniciou/liberou preparo'}
$script:PlanejAsync=@{Closing=$false;Job=[pscustomobject]@{Key='usuario'};Pending=$null;Ready=$null}
Start-PlanejamentoWarmup
if($script:Requests.Count -ne 1){throw 'Preparo substituiu pedido do usuario'}
$script:PlanejAsync.Job=$null;$script:PlanejAsync.Ready=[pscustomobject]@{Key='inicial'}
Start-PlanejamentoWarmup
if($script:Requests.Count -ne 1){throw 'Recalculou resultado pronto e valido'}
$script:SnapshotKey='apos-sync';Start-PlanejamentoWarmup
if($script:Requests[-1] -ne 'apos-sync'){throw 'Nao capturou dados atuais'}
# Execute actual startup handler; Sync is synthetic, timers are synthetic.
$script:PlanejAsync=$null;$script:PlanejWarmupTimer=$null;$script:Requests=@();$script:Timers=@()
$script:Config=[pscustomobject]@{sincronizar_ao_abrir=$true;planilha_base='base-sintetica.xlsx'}
$script:lblSyncStatus=[pscustomobject]@{Text=''}
function Sync-FromBase($Auto){if(-not $Auto){throw 'Modo sync alterado'};$script:SnapshotKey='dados-sincronizados'}
$shown=$ast.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text.StartsWith('$form.add_Shown(') -and $n.Extent.Text.Contains('$script:Config.sincronizar_ao_abrir')},$true)
$body=$shown.Arguments[0].ScriptBlock.Extent.Text
. ([scriptblock]::Create($body.Substring(1,$body.Length-2)))
if(-not $script:PlanejBootSyncPending -or $script:Timers.Count -ne 1){throw 'Handler nao aguardou sync'}
$script:Timers[0].Fire()
if($script:PlanejBootSyncPending -or $script:Timers.Count -ne 2 -or $script:Requests.Count){throw 'Preparo nao foi agendado depois do sync'}
$script:Timers[1].Fire()
if($script:Requests.Count -ne 1 -or $script:Requests[0] -ne 'dados-sincronizados'){throw 'Preparo usou dados anteriores ao sync'}
# No sync branch schedules warmup directly.
$script:Config.sincronizar_ao_abrir=$false;$script:Requests=@();$script:Timers=@()
. ([scriptblock]::Create($body.Substring(1,$body.Length-2)))
if($script:Timers.Count -ne 1){throw 'Sem sync nao agendou'}
$script:Timers[0].Fire()
if($script:Requests.Count -ne 1){throw 'Sem sync nao preparou'}
# Close pending timer with no active worker.
Request-PlanejamentoWarmup;$closingTimer=$script:PlanejWarmupTimer
Stop-PlanejamentoComputation
if(-not $closingTimer.Disposed -or -not $script:PlanejWarmupClosed){throw 'Timer pendente nao liberado ao fechar'}
$before=$script:Requests.Count;Start-PlanejamentoWarmup;Request-PlanejamentoWarmup
if($script:Requests.Count -ne $before){throw 'Preparo depois do fechamento'}
'Warmup aprovado: agenda uma vez; aguarda sync real do handler; usa copia atual; sem sync tambem prepara; nao substitui pedido ativo/cache valido; libera timer ao fechar. Timers e sincronizacao sinteticos, WinForms real nao executado.'
