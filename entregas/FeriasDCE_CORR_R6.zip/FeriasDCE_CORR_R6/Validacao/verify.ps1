﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$paths=@((Join-Path $PSScriptRoot 'Referencia_PERF_R5.ps1'),(Join-Path (Split-Path $root -Parent) 'FeriasDCE.ps1'))
$maps=@();$asts=@()
foreach($path in $paths){
 $tokens=$null;$errors=$null;$a=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
 $asts+=,$a;$map=@{};foreach($f in $a.EndBlock.Statements){if($f -is [Management.Automation.Language.FunctionDefinitionAst]){$map[$f.Name]=$f.Extent.Text.Replace('PERF-R5','CORR-R6')}};$maps+=,$map
}
$protected=@('Save-Database','Assert-DatabaseStructure','Assert-ValidJsonFile','Get-TextSha256','Acquire-DatabaseLock','Get-DiskDbState','Read-DatabaseSnapshotWithRetry','Restore-DatabaseSafely','Invoke-DatabaseFileReplace','Invoke-DatabaseAtomicRename','Invoke-DatabaseCompatibleReplace','Commit-DatabaseTempFile','Save-MemoryRescueSnapshot','Invoke-RoutineBackupRetention')
$checked=0;foreach($name in $protected){if(-not $maps[0].ContainsKey($name)){throw "Protecao ausente: $name"};if($maps[0][$name] -ne $maps[1][$name]){throw "Protecao mudou: $name"};$checked++}
foreach($prefix in @('$btnDesfazerAprovacao.add_Click(','$btnDesfazerFR.add_Click(','$btnAprovarFR.add_Click(')){
 $texts=@();foreach($a in $asts){$f=$a.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Abrir-CentralAprovacaoServidor'},$true);$n=$f.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text.StartsWith($prefix)},$true);if(-not $n){throw "Handler ausente: $prefix"};$texts+=,$n.Extent.Text}
 if($texts[0] -ne $texts[1]){throw "Handler de decisao mudou: $prefix"}
}
$main=@();foreach($a in $asts){$main+=,@($a.EndBlock.Statements|Where-Object {$_ -isnot [Management.Automation.Language.FunctionDefinitionAst]}|ForEach-Object {$_.Extent.Text.Replace('PERF-R5','CORR-R6')})}
if($main[0].Count -ne $main[1].Count){throw 'Estrutura principal mudou fora do escopo'}
for($i=0;$i -lt $main[0].Count;$i++){
 if($main[0][$i] -ne $main[1][$i] -and -not $main[0][$i].StartsWith('$btnSalvarPoliticaMensal.add_Click(')){throw "Mudanca principal fora do escopo, indice $i"}
}
$bytes=[IO.File]::ReadAllBytes($paths[1]);if($bytes[0] -ne 239 -or $bytes[1] -ne 187 -or $bytes[2] -ne 191){throw 'BOM ausente'}
$text=[IO.File]::ReadAllText($paths[1]);if($text.Replace("`r`n",'').Contains("`n")){throw 'LF isolado'}
$changed=@($maps[0].Keys|Where-Object {$maps[0][$_] -ne $maps[1][$_]}|Sort-Object)
$added=@($maps[1].Keys|Where-Object {-not $maps[0].ContainsKey($_)}|Sort-Object)
$allowed=@('Cadastrar-FeriasFixaManual','Corrigir-PeriodoSelecionado','Get-ContagemInstitucionalAprovadaMes','Get-EstadoLinhaPlanejamento','Get-OpcaoPlanejamento','Get-OptionBlocksObjeto','Get-PesoOpcaoInstitucionalMes','Get-PlanejamentoViewModel','Importar-FeriasFixas2027','Load-Database','New-PlanejamentoComputation','Refresh-ConfigInfo','Refresh-Dashboard','Reset-FixasImportadas','Reset-PlanejamentoAtual','Restaurar-UltimoPreReset','Set-PlanejamentoUiFalha','Show-RelatorioAceitesEnfermagem','Show-RelatorioConferenciaOpcoes')
if(@(Compare-Object $changed $allowed).Count){throw 'Funcao mudou fora do escopo revisado'}
if($added.Count -ne 4){throw 'Novas funcoes fora do escopo revisado'}
[ordered]@{parser_errors=0;protected_functions_identical=$checked;decision_handlers_identical=3;bom=$true;crlf=$true;source_sha256=(Get-FileHash $paths[1] -Algorithm SHA256).Hash;changed_functions=$changed;added_functions=$added}|ConvertTo-Json -Depth 5|Set-Content "$root/RESULTADOS_ESTRUTURA.json" -Encoding UTF8
"Parser sem erros; $checked funcoes de persistencia/protecao e 3 handlers de decisao preservados; BOM/CRLF conferidos."
