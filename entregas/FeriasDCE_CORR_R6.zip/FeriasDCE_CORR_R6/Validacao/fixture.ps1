﻿$script:Config=[pscustomobject]@{total_enfermeiros_planejamento=189;meses_restritos=@(1,7,12);limites_especiais_mensais=[pscustomobject]@{'1'=10;'7'=10;'12'=10};periodos=@('DIURNO','MATUTINO','NOTURNO');grupo_analise_setores=@();grupo_chefia_setores=@();grupo_chefia_servidores=@();limites_setor_periodo=@();limites_chefia_periodo=@();historico_3_anos_importado=$false}
$script:HistoricoFerias=@();$script:LoadedDbHash='sintetico';$script:PlanejGrupoSelecionado='TODOS';$script:PlanejSetoresSelecionados=@();$script:PlanejPeriodosSelecionados=@();$script:cmbPlanejChefia=$null
$list=New-Object 'System.Collections.Generic.List[object]'
for($i=1;$i -le $Quantidade;$i++){
 $r=[pscustomobject]@{id=$i;matricula=('M'+([int][math]::Ceiling($i/2)));nome=('Servidor sintetico '+$i);setor=('Setor '+($i%14));periodo=@('DIURNO','MATUTINO','NOTURNO')[$i%3];aquisitivo_inicio='2026-01-01';aquisitivo_fim='2026-12-31'}
 [void](Initialize-RecordDefaults $r)
 for($n=1;$n -le 3;$n++){
  $d=[datetime]::new((2027+[int]($i%7 -eq 0)),(1+(($i+$n)%12)),(1+($i%12)))
  $op=New-EmptyOptionObject
  $op.tipo=if($i%3 -eq 0){'15+15 DIAS'}else{'30 DIAS'}
  $op.inicio1=$d.ToString('yyyy-MM-dd');$op.fim1=$d.AddDays($(if($op.tipo -eq '30 DIAS'){29}else{14})).ToString('yyyy-MM-dd')
  if($op.tipo -eq '15+15 DIAS'){$op.inicio2=$d.AddMonths(4).ToString('yyyy-MM-dd');$op.fim2=$d.AddMonths(4).AddDays(14).ToString('yyyy-MM-dd')}
  if($i%5 -eq 0){$op.tipo='30 DIAS';$op.fim1=$d.AddDays(29).ToString('yyyy-MM-dd');$op.fr_inicio=$d.AddMonths(6).ToString('yyyy-MM-dd');$op.fr_fim=$d.AddMonths(6).AddDays(19).ToString('yyyy-MM-dd')}
  $r.("opcao$n")=$op
 }
 if($i%4 -ne 0){$r.opcao_aprovada=1+($i%3)}
 if($i%5 -eq 0){$r.fr_opcao_aprovada=2}
 if($i%9 -eq 0){$r.ferias_bloqueadas=$true;$r.fixo_inicio=$r.opcao1.inicio1;$r.fixo_fim=$r.opcao1.fim1}
 $list.Add($r)
}
$script:Records=@($list.ToArray())
