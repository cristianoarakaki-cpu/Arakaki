const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname;
const html=fs.readFileSync(root+'/RELATORIO_SINTETICO.html','utf8');
const data=JSON.parse(html.match(/<script id="dados" type="application\/json">([\s\S]*?)<\/script>/)[1]);
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];assert(scripts.length===1);
const code=scripts[0][1];
class El{constructor(tag='div'){this.tag=tag;this.children=[];this.value='';this.events={};this.classList={add(){}};this._text='';}set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text;}appendChild(e){this.children.push(e);}addEventListener(n,f){this.events[n]=f;}scrollIntoView(){}}
const initial=[...html.matchAll(/<tr><td>([^<]+)<\/td><td>[^<]*<\/td><td>[^<]*<\/td><td>[^<]*<\/td><td class="[^"]*">([^<]+)<\/td><td>([^<]+)<\/td><\/tr>/g)].map(x=>({mes:x[1],total:Number(x[2].replace(',','.')),lim:x[3]}));assert(initial.length===24);
function execute(records){const elements={};for(const id of ['dados','filtro-setor','contador','titulo-detalhes','lista-detalhes','detalhes','limpar'])elements[id]=new El();elements.dados.textContent=JSON.stringify(records);const tbody=new El('tbody');
 const document={getElementById:id=>elements[id],createElement:t=>new El(t),querySelector:sel=>{assert(sel==='#resumo tbody');return tbody;},querySelectorAll:sel=>{assert(sel==='#resumo tbody tr:not(.total)');return initial.map(r=>({cells:[{textContent:r.mes},null,null,null,null,{textContent:r.lim}]}));}};
 vm.runInNewContext(code,{document,Map,Set,Array,Number,Math});
 const value=mes=>{const row=tbody.children.find(r=>r.children[0].textContent===mes);assert(row);return Number(row.children[4].textContent.replace(',','.'));};
 return {elements,tbody,value,filter:sector=>{elements['filtro-setor'].value=sector;elements['filtro-setor'].events.change();}};
}
let run=execute(data);for(const m of initial)assert.strictEqual(run.value(m.mes),m.total,'Resumo HTML diverge do inicial: '+m.mes);
assert.strictEqual(run.value('fev/2027'),1);run.filter('A');assert.strictEqual(run.value('fev/2027'),1);run.filter('NAO EXISTE');assert.strictEqual(run.value('fev/2027'),0);
const extra={...data.find(x=>x.mes==='fev/2027'),chave:'OUTRO|2026-01-01|2026-12-31',setor:'B',peso_institucional:0.5};
run=execute([...data,...data.map(r=>({...r,registro:r.registro+100})),extra]);assert.strictEqual(run.value('fev/2027'),1.5);run.filter('A');assert.strictEqual(run.value('fev/2027'),1);run.filter('B');assert.strictEqual(run.value('fev/2027'),0.5);
const message='HTML/JavaScript: 24 totais iniciais equivalentes ao recalculo; filtro por setor; comum/FR sem duplicacao; registros duplicados pelo mesmo aquisitivo; segundo setor com 0,5. DOM simulado, sem navegador Windows.';
fs.writeFileSync(root+'/RESULTADOS_HTML.txt',message+'\n');console.log(message);
