﻿$ErrorActionPreference='Stop'
. "$PSScriptRoot/test_regressao.ps1"
Reset-Fixture
$r=New-Record;$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-01-01';$r.fixo_fim='2027-01-15';$r|Add-Member NoteProperty fixos_adicionais @([pscustomobject]@{inicio='2027-03-01';fim='2027-03-15'})
$r2=New-Record 2 TESTE2;$r2.opcao1=New-Common '2027-03-01';$r2.opcao_aprovada=1;$r2.opcao2=New-Common '2027-04-01';$r2.opcao2.fr_inicio='2027-08-01';$r2.opcao2.fr_fim='2027-08-20';$r2.fr_opcao_aprovada=2
$script:Records=@($r,$r2)
$rs=$null;$checked=0
try{
 foreach($case in @(
  @{Situacao='TODAS AS LINHAS';Sobreposicao=$false;Total=189},
  @{Situacao='COM FÉRIAS FIXAS';Sobreposicao=$false;Total=189},
  @{Situacao='SOMENTE CRÍTICAS';Sobreposicao=$false;Total=6},
  @{Situacao='TODAS AS LINHAS';Sobreposicao=$true;Total=189},
  @{Situacao='SEM LIMITE';Sobreposicao=$false;Total=0}
 )){
  $script:Config.total_enfermeiros_planejamento=$case.Total
  $f=[pscustomobject]@{Ano=2027;Mes=0;Situacao=$case.Situacao;Sobreposicao=$case.Sobreposicao;Busca='';Grupo='TODOS';Chefia='TODOS';Setores=@();Periodos=@()}
  $expected=Get-PlanejamentoViewModel $f
  $json=@{Config=$script:Config;Registros=$script:Records;Filtro=$f;Hash='teste';Culture='pt-BR';UICulture='pt-BR'}|ConvertTo-Json -Depth 20
  $job=New-PlanejamentoComputation $json $rs;$rs=$job.Runspace
  $watch=[Diagnostics.Stopwatch]::StartNew()
  while(-not $job.Handle.IsCompleted){if($watch.Elapsed.TotalSeconds -gt 30){throw 'Timeout worker'};Start-Sleep -Milliseconds 15}
  $result=$job.PowerShell.EndInvoke($job.Handle)
  if($job.PowerShell.HadErrors){throw ($job.PowerShell.Streams.Error|Out-String)}
  $job.PowerShell.Dispose()
  if($result.Count -ne 1 -or $result[0].Linhas.Count -ne $expected.Linhas.Count){throw "Filtro no worker divergiu: $($case.Situacao)"}
  foreach($m in 1..12){if($result[0].Meses[$m].real -ne $expected.Meses[$m].real -or $result[0].Meses[$m].qtd -ne $expected.Meses[$m].qtd){throw "Peso mensal worker divergiu: $m"}}
  $checked++
 }
}finally{if($null -ne $rs){$rs.Close();$rs.Dispose()}}
"Worker real: $checked combinacoes de filtros e limites concordam com calculo sincrono, incluindo parcelas adicionais e FR independente."|Tee-Object -FilePath "$PSScriptRoot/RESULTADOS_WORKER_FILTROS.txt"
