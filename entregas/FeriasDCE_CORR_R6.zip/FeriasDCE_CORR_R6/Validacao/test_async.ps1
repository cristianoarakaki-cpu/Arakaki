﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path (Split-Path $root -Parent) 'FeriasDCE.ps1'),[ref]$t,[ref]$e)
if($e.Count){throw ($e|Out-String)}
foreach($f in $ast.EndBlock.Statements){if($f -is [Management.Automation.Language.FunctionDefinitionAst]){. ([scriptblock]::Create($f.Extent.Text))}}
function Write-DiagLog {param($Message,$Level,$ErrorRecord)}
$Quantidade=180; . (Join-Path $PSScriptRoot 'fixture.ps1')
$script:cmbPlanejAno=[pscustomobject]@{SelectedItem='2027'}
$script:cmbPlanejMes=[pscustomobject]@{SelectedIndex=0}
$script:cmbPlanejSituacao=[pscustomobject]@{SelectedItem='TODAS AS LINHAS'}
$script:txtPlanejBuscaServidor=[pscustomobject]@{Text=''}
$script:chkPlanejSobreposicao=[pscustomobject]@{Checked=$false}
$script:cmbPlanejChefia=[pscustomobject]@{SelectedItem='TODOS'}
function Normalizar($model){
 $rows=@(foreach($item in $model.Linhas){
  $months=@(foreach($m in 1..12){[ordered]@{base=@($item.meses[$m]|Sort-Object);sol=@($item.solicitacoes[$m]|Sort-Object)}})
  [ordered]@{setor=$item.setor;periodo=$item.periodo;grupo=$item.grupo;chefia=$item.grupo_chefia;meses=$months}
 })
 $monthly=@(foreach($m in 1..12){$v=$model.Meses[$m];[ordered]@{qtd=$v.qtd;real=$v.real;limite=$v.limite;detalhes=$v.detalhes}})
 return ([ordered]@{Ano=$model.Ano;Linhas=$rows;Contadores=$model.Contadores;Meses=$monthly;Criticos=$model.Criticos}|ConvertTo-Json -Depth 18 -Compress)
}
$results=New-Object 'System.Collections.Generic.List[string]'
$snapshot=Get-PlanejamentoSnapshot
$primeiraCopiaMs=$script:PlanejUltimaCopiaMs
$filter=($snapshot.Json|ConvertFrom-Json).Filtro
$expected=Normalizar (Get-PlanejamentoViewModel $filter)
$sw=[Diagnostics.Stopwatch]::StartNew();$job=New-PlanejamentoComputation $snapshot.Json;$sw.Stop();$inicioMs=$sw.Elapsed.TotalMilliseconds
$oldSetor=$script:Records[0].setor;$script:Records[0].setor='ALTERADO ENQUANTO WORKER EXECUTA'
$script:Config.total_enfermeiros_planejamento=1
$beats=0
while(-not $job.Handle.IsCompleted){$beats++;Start-Sleep -Milliseconds 20}
$output=$job.PowerShell.EndInvoke($job.Handle)
if($output.Count -ne 1){throw 'Saida inesperada do worker'}
$actual=Normalizar $output[0]
if($actual -ne $expected){$actual|Set-Content '/tmp/actual.json';$expected|Set-Content '/tmp/expected.json';throw 'Modelos sincrono/worker diferem'}
$rs=$job.Runspace;$job.PowerShell.Dispose()
if($rs.RunspaceStateInfo.State -ne 'Opened'){throw 'Dispose de pipeline fechou o runspace reutilizavel'}
$results.Add('Runspace real calcula modelo equivalente ao sincrono em copia isolada; mutacoes na UI nao alteram a copia')
$results.Add("Inicio retornou em $([int]$inicioMs)ms; copia inicial em ${primeiraCopiaMs}ms; caller permaneceu ativo durante $beats ciclos enquanto o worker calculava")
$script:Records[0].setor=$oldSetor;$script:Config.total_enfermeiros_planejamento=189
# Use actual controller with no Windows timer/grid: only presentation is replaced.
$timer=[pscustomobject]@{Started=$false;Disposed=$false}
$timer|Add-Member ScriptMethod Start {$this.Started=$true}
$timer|Add-Member ScriptMethod Stop {$this.Started=$false}
$timer|Add-Member ScriptMethod Dispose {$this.Disposed=$true}
$script:PlanejAsync=@{Timer=$timer;Job=$null;Pending=$null;Ready=$null;Wanted='';Closing=$false;Runspace=$rs}
$rows=[pscustomobject]@{Cleared=$false};$rows|Add-Member ScriptMethod Clear {$this.Cleared=$true}
$script:gridPlanejSetor=[pscustomobject]@{Enabled=$true;Rows=$rows}
$script:gridLimiteInstitucional=[pscustomobject]@{Enabled=$true;Rows=@()}
$script:lblPlanejResumo=[pscustomobject]@{Text=''}
$script:tabsPrincipal=[pscustomobject]@{SelectedTab='plano'};$script:tabPlanejamentoPrincipal='plano'
$script:rendered=New-Object 'System.Collections.Generic.List[object]'
function Refresh-PlanejamentoSetor($Preparado){$script:rendered.Add($Preparado);$script:gridPlanejSetor.Enabled=$true;$script:gridLimiteInstitucional.Enabled=$true;$script:PlanejRefreshDirty=$false}
function Esperar-Controlador {
 $watch=[Diagnostics.Stopwatch]::StartNew()
 while($null -ne $script:PlanejAsync.Job -or $null -ne $script:PlanejAsync.Pending){
  Receive-PlanejamentoComputation
  if($watch.Elapsed.TotalSeconds -gt 60){throw 'Timeout de teste'}
  Start-Sleep -Milliseconds 15
 }
}
Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
$script:cmbPlanejMes.SelectedIndex=2;$latest=Get-PlanejamentoSnapshot
Request-PlanejamentoComputation $latest
Esperar-Controlador
if($script:rendered.Count -ne 1 -or $script:PlanejAsync.Ready.Key -ne $latest.Key){throw 'Resultado obsoleto sobrescreveu filtro recente'}
$results.Add('Pedidos sobrepostos: descarta resultado antigo e aplica somente o filtro mais recente')
$script:cmbPlanejMes.SelectedIndex=3;Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
$script:cmbPlanejMes.SelectedIndex=2;Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
Esperar-Controlador
if($script:rendered.Count -ne 2 -or $script:PlanejAsync.Ready.Key -ne $latest.Key){throw 'Voltar ao cache permitiu resultado antigo'}
$results.Add('Voltar a um resultado ja pronto enquanto outro calcula nao permite sobrescrita posterior')
# A save/import can change data without a filter event. The completion must revalidate data.
$script:cmbPlanejMes.SelectedIndex=4;Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
$script:Config.total_enfermeiros_planejamento=200
Esperar-Controlador
if($script:rendered.Count -ne 3 -or $script:PlanejAsync.Ready.Key -ne (Get-PlanejamentoSnapshot).Key){throw 'Mudanca da base/configuracao nao invalidou resultado em voo'}
$results.Add('Alteracao de configuracao durante calculo invalida modelo em voo e solicita uma copia atualizada')
$script:tabsPrincipal.SelectedTab='outra'
$script:cmbPlanejMes.SelectedIndex=5;Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
Esperar-Controlador
if($script:rendered.Count -ne 3 -or -not $script:PlanejRefreshDirty){throw 'Aplicou dados em aba oculta'}
$script:tabsPrincipal.SelectedTab='plano';Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
if($script:rendered.Count -ne 4){throw 'Resultado de aba oculta nao reaproveitado ao voltar'}
$results.Add('Aba oculta recebe resultado em cache, sem renderizar; ao voltar reaproveita o modelo atual')
# Failure stays visible and never invokes rendering or a save.
$job=New-PlanejamentoComputation -Json 'JSON INVALIDO' -Runspace $script:PlanejAsync.Runspace
$job|Add-Member NoteProperty Key 'erro'
$script:PlanejAsync.Job=$job;$script:PlanejAsync.Wanted='erro'
Esperar-Controlador
if($script:rendered.Count -ne 4 -or $script:lblPlanejResumo.Text -notlike 'Falha ao calcular*'){throw 'Falha de worker foi ocultada'}
$results.Add('Falha real do pipeline nao aplica modelo e informa erro; nenhuma gravacao e feita')
if(-not $script:gridPlanejSetor.Enabled -or -not $script:gridLimiteInstitucional.Enabled -or -not $rows.Cleared -or $null -ne $script:PlanejAsync.Ready){throw 'Falha deixou dados antigos ou controles desabilitados'}
$results.Add('Falha real libera ambas as grades, descarta cache pronto e remove linhas antigas; permite tentar novamente')
# Recovered worker failure must accept another real calculation.
Request-PlanejamentoComputation (Get-PlanejamentoSnapshot);Esperar-Controlador
if($script:rendered.Count -ne 5 -or $script:PlanejRefreshDirty){throw 'Nao recuperou apos falha do pipeline'}
$results.Add('Nova tentativa apos falha usa runspace real e entrega resultado atualizado')
# A start failure is different from a running pipeline failure.
$originalNew=(Get-Command New-PlanejamentoComputation -CommandType Function).Definition
function New-PlanejamentoComputation {param($Json,$Runspace)throw 'falha sintetica ao iniciar'}
$script:cmbPlanejMes.SelectedIndex=6
Request-PlanejamentoComputation (Get-PlanejamentoSnapshot)
if(-not $script:gridPlanejSetor.Enabled -or -not $script:gridLimiteInstitucional.Enabled -or $script:lblPlanejResumo.Text -notlike 'Nao foi possivel iniciar*'){throw 'Inicio falhou e deixou UI presa'}
. ([scriptblock]::Create('function New-PlanejamentoComputation {'+$originalNew+'}'))
$results.Add('Falha de inicializacao tambem libera controles e informa tentativa disponivel')
# Hidden warmup must not touch grid state or labels, even on error.
$script:tabsPrincipal.SelectedTab='outra';$script:lblPlanejResumo.Text='inalterado'
$script:gridPlanejSetor.Enabled=$true;$script:gridLimiteInstitucional.Enabled=$true;$rows.Cleared=$false
Set-PlanejamentoUiCalculando
Set-PlanejamentoUiFalha 'erro oculto'
if($script:lblPlanejResumo.Text -ne 'inalterado' -or -not $script:gridPlanejSetor.Enabled -or $rows.Cleared){throw 'Alterou UI de aba oculta'}
$script:tabsPrincipal.SelectedTab='plano'
$results.Add('Warmup/falha ocultos nao alteram controles; erro invalida dados para nova tentativa ao visitar a aba')
Stop-PlanejamentoComputation
if($null -ne $script:PlanejAsync -or -not $timer.Disposed){throw 'Recursos nao encerrados'}
$results.Add('Encerramento libera timer, pipeline e runspace privado')
$results|Set-Content "$root/RESULTADOS_ASYNC.txt" -Encoding UTF8
Write-Output ($results -join "`n")
