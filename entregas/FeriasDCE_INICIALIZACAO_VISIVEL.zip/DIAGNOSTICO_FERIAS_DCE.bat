@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -File "%~dp0FeriasDCE_Launcher.ps1"
set "FERIAS_EXIT_CODE=%ERRORLEVEL%"
echo.
echo Codigo de saida: %FERIAS_EXIT_CODE%
pause
exit /b %FERIAS_EXIT_CODE%
