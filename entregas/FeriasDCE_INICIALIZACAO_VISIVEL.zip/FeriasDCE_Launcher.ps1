﻿#requires -version 5.1
[CmdletBinding()]
param([switch]$ValidarSomente)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$main=Join-Path $root 'FeriasDCE.ps1'
$logFile=''
$logAviso=''
$stamp=(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'_'+[guid]::NewGuid().ToString('N')
# Tenta o log habitual e depois uma pasta TEMP do usuario; nenhuma politica e alterada.
$logDirs=@((Join-Path $root 'Logs'),(Join-Path ([IO.Path]::GetTempPath()) 'FeriasDCELogs'))
foreach($dir in $logDirs){
    try {
        if(-not (Test-Path -LiteralPath $dir -PathType Container)){
            [void](New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop)
        }
        $candidate=Join-Path $dir ("INICIALIZADOR_$stamp.log")
        $stream=[IO.File]::Open($candidate,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
        $stream.Dispose()
        $logFile=$candidate
        break
    } catch { $logAviso=$_.Exception.Message }
}
function Log([string]$msg,[string]$level='INFO'){
    if(-not $logFile){return}
    try {
        $ts=Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
        [IO.File]::AppendAllText($logFile,"[$ts] [$level] $msg"+[Environment]::NewLine,[Text.UTF8Encoding]::new($true))
    } catch {
        Write-Warning ('Falha ao escrever o log: '+$_.Exception.Message)
    }
}
function Log-ErrorRecord($e){
    Log ("Tipo: "+$e.Exception.GetType().FullName) 'ERROR'
    Log ("Mensagem: "+$e.Exception.Message) 'ERROR'
    if($e.FullyQualifiedErrorId){Log ("ErrorId: "+$e.FullyQualifiedErrorId) 'ERROR'}
    if($e.InvocationInfo -and $e.InvocationInfo.PositionMessage){Log ("Local: "+$e.InvocationInfo.PositionMessage) 'ERROR'}
    if($e.ScriptStackTrace){Log ("Pilha: "+$e.ScriptStackTrace) 'ERROR'}
}
Write-Host 'Ferias DCE - inicializacao visivel, conforme a politica de execucao vigente.'
if($logFile){Write-Host ('Log: '+$logFile)}else{Write-Warning ('Nao foi possivel criar log; o erro sera mostrado nesta janela. '+$logAviso)}
Log 'Inicializador revisado - sem mudar politica, ocultar janela ou criar processo intermediario.'
Log ('Pasta: '+$root)
Log ('PowerShell: '+$PSVersionTable.PSVersion.ToString())
Log ('PID: '+$PID)
if($logAviso){Log ('Tentativa anterior de criar log falhou: '+$logAviso) 'WARN'}
try {
    if(-not (Test-Path -LiteralPath $main -PathType Leaf)){throw "Arquivo principal nao encontrado: $main"}
    $tokens=$null;$parseErrors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($main,[ref]$tokens,[ref]$parseErrors)
    if($parseErrors.Count -gt 0){
        foreach($pe in $parseErrors){Log ("PARSE linha $($pe.Extent.StartLineNumber), coluna $($pe.Extent.StartColumnNumber): $($pe.Message)") 'ERROR'}
        throw 'FeriasDCE.ps1 contem erro de sintaxe. A execucao foi cancelada.'
    }
    Log 'Validacao de sintaxe concluida sem erros.'
    if($ValidarSomente){
        Write-Host 'Sintaxe validada. O aplicativo nao foi executado.'
        exit 0
    }
    Log 'Iniciando FeriasDCE.ps1.'
    & $main
    Log 'FeriasDCE.ps1 terminou sem excecao nao tratada.'
    exit 0
} catch {
    $erroInicial=$_
    Log 'FALHA NA INICIALIZACAO.' 'FATAL'
    Log-ErrorRecord $erroInicial
    $msg="O sistema nao conseguiu iniciar.`r`n`r`n"+$erroInicial.Exception.Message
    if($logFile){$msg+="`r`n`r`nLog: $logFile"}else{$msg+="`r`n`r`nNao foi possivel salvar o log."}
    Write-Host $msg -ForegroundColor Red
    if($env:OS -eq 'Windows_NT'){
        try {
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
            [void][System.Windows.Forms.MessageBox]::Show($msg,'Ferias DCE - erro de inicializacao',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
        } catch {Write-Warning 'Nao foi possivel abrir a caixa de mensagem; consulte o erro no console.'}
    }
    exit 1
}
