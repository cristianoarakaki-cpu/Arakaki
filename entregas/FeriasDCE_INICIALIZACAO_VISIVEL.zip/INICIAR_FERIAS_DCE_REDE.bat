@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -File "%~dp0FeriasDCE_Launcher.ps1"
set "FERIAS_EXIT_CODE=%ERRORLEVEL%"
if not "%FERIAS_EXIT_CODE%"=="0" (
    echo.
    echo O sistema terminou com erro. Consulte a mensagem e o log informado.
    pause
)
exit /b %FERIAS_EXIT_CODE%
