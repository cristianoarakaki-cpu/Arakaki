﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$AppRoot = $PSScriptRoot, [string]$ReportPath = '')
$ErrorActionPreference='Stop'
$linhas=New-Object 'System.Collections.Generic.List[string]'
function Registrar([string]$Mensagem){
    $linhas.Add($Mensagem)
    Write-Host $Mensagem
}
function Criar-ArquivoTeste([string]$Caminho,[string]$Texto){
    $f=$null
    try {
        $f=[IO.File]::Open($Caminho,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $bytes=[Text.Encoding]::UTF8.GetBytes($Texto)
        $f.Write($bytes,0,$bytes.Length)
        $f.Flush()
    } finally { if($null -ne $f){$f.Dispose()} }
}
function Registrar-Erro([string]$Etapa,$Erro){
    $e=$Erro.Exception
    while($null -ne $e.InnerException){$e=$e.InnerException}
    Registrar ("FALHOU | {0} | {1} | HResult={2} | {3}" -f $Etapa,$e.GetType().FullName,$e.HResult,$e.Message)
}
function Registrar-ACL([string]$Caminho){
    if($env:OS -ne 'Windows_NT'){Registrar 'ACL Windows: nao disponivel neste sistema.';return}
    try {
        $acl=Get-Acl -LiteralPath $Caminho -ErrorAction Stop
        Registrar ("ACL | {0} | Proprietario: {1}" -f $Caminho,$acl.Owner)
        foreach($a in $acl.Access){
            Registrar ("  {0} | {1} | {2} | Herdada={3}" -f $a.IdentityReference,$a.AccessControlType,$a.FileSystemRights,$a.IsInherited)
        }
        Registrar 'As entradas ACL acima nao calculam permissoes efetivas nem substituem a verificacao das permissoes do compartilhamento pela TI.'
    } catch {Registrar-Erro 'Consulta de ACL' $_}
}
Registrar 'DIAGNOSTICO FERIAS DCE - SEM ALTERAR A BASE REAL'
Registrar ('Data local: '+(Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
Registrar ('PowerShell: '+$PSVersionTable.PSVersion.ToString())
Registrar 'Este teste cria/substitui/remove somente arquivos descartaveis com prefixo .diagnostico_ferias_ e identificador exclusivo.'
Registrar 'Nao modifica JSON real, backups existentes, atributos, ACL, antivirus ou politicas do Windows.'
try {
    $raiz=[IO.Path]::GetFullPath($AppRoot)
    $dados=Join-Path $raiz 'Dados'
    $base=Join-Path $dados 'ferias_2027.json'
    Registrar ('Aplicacao: '+$raiz)
    Registrar ('Pasta de dados: '+$dados)
    if(-not (Test-Path -LiteralPath $dados -PathType Container)){throw 'Pasta Dados nao encontrada/acessivel. Coloque os arquivos do diagnostico ao lado de FeriasDCE.ps1.'}
    Registrar-ACL $dados
    if(Test-Path -LiteralPath $base){
        $item=Get-Item -LiteralPath $base -ErrorAction Stop
        Registrar ('Atributos do JSON real: '+[string]$item.Attributes)
        if(($item.Attributes -band [IO.FileAttributes]::ReadOnly) -ne 0){Registrar 'ATENCAO: JSON real esta marcado como somente leitura. O diagnostico nao remove este atributo.'}
        Registrar-ACL $base
    } else {Registrar 'JSON real nao encontrado/acessivel neste caminho. Nao sera criado pelo diagnostico.'}
    $prefixo=Join-Path $dados ('.diagnostico_ferias_'+[guid]::NewGuid().ToString('N'))
    $dest=$prefixo+'_destino.tmp'
    $novo=$prefixo+'_novo.tmp'
    $backup=$prefixo+'_backup.tmp'
    $movido=$prefixo+'_movido.tmp'
    $criados=New-Object 'System.Collections.Generic.List[string]'
    try {
        try {
            Criar-ArquivoTeste $dest '{"teste":"anterior"}'
            $criados.Add($dest)
            Criar-ArquivoTeste $novo '{"teste":"novo"}'
            $criados.Add($novo)
            Registrar 'OK | Criacao de arquivos novos na pasta Dados.'
            # Mesmo metodo de substituicao usado pelo aplicativo, somente em descartaveis.
            $criados.Add($backup)
            [IO.File]::Replace($novo,$dest,$backup)
            if([IO.File]::ReadAllText($dest) -ne '{"teste":"novo"}'){throw 'O destino de teste diverge do conteudo esperado.'}
            if([IO.File]::ReadAllText($backup) -ne '{"teste":"anterior"}'){throw 'O backup de teste diverge do conteudo anterior.'}
            Registrar 'OK | File.Replace com backup e conferencia dos dois conteudos.'
            $criados.Add($movido)
            [IO.File]::Move($dest,$movido)
            Registrar 'OK | Renomeacao de arquivo descartavel na pasta Dados.'
        } catch {Registrar-Erro 'Criacao/substituicao/renomeacao de descartaveis' $_}
    } finally {
        foreach($p in $criados){
            try {
                if(Test-Path -LiteralPath $p){[IO.File]::Delete($p);Registrar ('OK | Remocao do descartavel '+[IO.Path]::GetFileName($p))}
            } catch {Registrar-Erro ('Limpeza do descartavel '+$p) $_}
        }
    }
    Registrar ''
    Registrar 'INTERPRETACAO'
    Registrar '- Se o teste descartavel falhar: TI deve verificar permissao Modificar (criar, gravar, renomear e excluir) em Dados, tanto no compartilhamento SMB quanto no NTFS, alem de bloqueios de processo/provedor.'
    Registrar '- Se o teste passar e o programa continuar negando acesso: verificar ACL/atributo somente leitura especificamente do JSON real, bloqueio de outro processo e regras de protecao de endpoint. O sucesso no descartavel nao comprova permissao no arquivo existente.'
    Registrar '- Nao e recomendado desativar antivirus, dar controle total a Todos ou substituir a gravacao atomica por sobrescrita direta.'
    Registrar '- A pasta Backups e os arquivos ERRO_SALVAMENTO ja criados devem ser preservados; nao restaurar automaticamente por cima da base.'
} catch {Registrar-Erro 'Preparacao do diagnostico' $_}
try {
    if([string]::IsNullOrWhiteSpace($ReportPath)){
        $ReportPath=Join-Path ([IO.Path]::GetTempPath()) ('Diagnostico_Ferias_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N')+'.txt')
    }
    # Relatorio sempre novo: nunca sobrescreve arquivo preexistente, mesmo se informado pelo usuario.
    Criar-ArquivoTeste $ReportPath (($linhas -join [Environment]::NewLine)+[Environment]::NewLine)
    Write-Host ("`nRELATORIO SALVO EM: "+$ReportPath) -ForegroundColor Cyan
} catch { Write-Warning ('Nao foi possivel salvar o relatorio: '+$_.Exception.Message) }
