@echo off
powershell.exe -NoLogo -NoProfile -File "%~dp0Diagnosticar-GravacaoFerias.ps1" -AppRoot "%~dp0."
echo.
pause
