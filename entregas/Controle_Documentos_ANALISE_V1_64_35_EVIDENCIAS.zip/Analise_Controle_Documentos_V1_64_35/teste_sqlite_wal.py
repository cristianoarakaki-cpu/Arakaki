from pathlib import Path
import tempfile,sqlite3,shutil,json
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='controle-documentos-wal-') as folder:
 p=Path(folder);conn=sqlite3.connect(p/'ativo.db');conn.execute('pragma journal_mode=WAL');conn.execute('pragma wal_autocheckpoint=0');conn.execute('create table documentos(id integer primary key,numero text)');conn.commit();conn.execute('pragma wal_checkpoint(TRUNCATE)')
 conn.execute("insert into documentos values(1,'FICTICIO')");conn.commit()
 assert (p/'ativo.db-wal').exists()
 shutil.copy2(p/'ativo.db',p/'copia_somente_db.db')
 cp=sqlite3.connect(p/'copia_somente_db.db')
 result={'banco_com_conexao_e_wal':conn.execute('select count(*) from documentos').fetchone()[0],'copia_somente_db':cp.execute('select count(*) from documentos').fetchone()[0],'integrity_check_copia':cp.execute('pragma integrity_check').fetchone()[0],'escopo':'Demonstra SQLite/WAL. Nao executa Restore-DatabaseBackupSafe nem worker/Windows reais.'}
 assert result['banco_com_conexao_e_wal']==1 and result['copia_somente_db']==0 and result['integrity_check_copia']=='ok'
 cp.close();conn.close()
(root/'RESULTADO_SQLITE_WAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
