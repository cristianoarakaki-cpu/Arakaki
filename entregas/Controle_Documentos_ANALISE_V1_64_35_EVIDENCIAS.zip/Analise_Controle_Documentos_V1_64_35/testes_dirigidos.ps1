﻿param([string]$SourceDirectory=(Join-Path $PSScriptRoot 'CONTROLE_DOCUMENTOS_V1_64_35_RESTAURACAO_GRADE'))
$ErrorActionPreference='Stop'
$RootAudit=$PSScriptRoot
$trees=@{}
$hashesEsperados=@{'Controle_Documentos.ps1'='C9B3CC9A61A67AAF519386E50ED3DE0EFE9D5C816A1F82A9FB6D91D0055EFD46';'Motor_Dados.ps1'='42FE0C68769C511A33EE6EBFA6596631A1E19093ECA68CDF8B4524C6E9BC604A'}
foreach($name in @('Controle_Documentos.ps1','Motor_Dados.ps1')){
 if((Get-FileHash (Join-Path $SourceDirectory $name)).Hash -ne $hashesEsperados[$name]){throw ('Fonte diferente da V1.64.35 avaliada: '+$name)}
 $t=$null;$e=$null;$trees[$name]=[Management.Automation.Language.Parser]::ParseFile((Join-Path $SourceDirectory $name),[ref]$t,[ref]$e)
 if($e.Count){throw ($e|Out-String)}
}
function Load-Functions([string]$File,[string[]]$Names){
 foreach($name in $Names){
  $fn=$trees[$File].Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
  if($null -eq $fn){throw "Funcao ausente: $name"}
  . ([scriptblock]::Create('function global:'+$name+$fn.Extent.Text.Substring(('function '+$name).Length)))
 }
}
function Ensure-Directory([string]$path){[void][IO.Directory]::CreateDirectory($path)}
function Write-AppLog {param($Message,$Level)}
function Msg-Info {param($Message)}
function Msg-Error {param($Message)}
Add-Type @'
namespace System.Windows.Forms {
 public enum DialogResult {Yes,No,Cancel,OK}
 public enum MessageBoxButtons {YesNo,YesNoCancel,OK}
 public enum MessageBoxIcon {Warning,Information,Error,Exclamation}
 public enum MessageBoxDefaultButton {Button1,Button2}
 public static class MessageBox { public static DialogResult Show(params object[] values){return DialogResult.Yes;} }
}
'@
$work=Join-Path $RootAudit ('FICTICIO_'+[guid]::NewGuid().ToString('N'))
Ensure-Directory $work
$results=[Collections.Generic.List[object]]::new()
function Finding([string]$id,[string]$Observed){$results.Add([pscustomobject]@{id=$id;observado=$Observed})}
try{
 # P01: actual finalizer executes even if another process already owns the motor locks.
 $motor=$trees['Motor_Dados.ps1'];$outer=@($motor.EndBlock.Statements|Where-Object {$_ -is [Management.Automation.Language.TryStatementAst]})[-1]
 if(-not $outer.Finally){throw 'Finalizador ausente'}
 $script:RootDir=Join-Path $work 'pc1';$script:Shared=Join-Path $work 'rede';Ensure-Directory (Join-Path $script:RootDir 'Dados');Ensure-Directory (Join-Path $script:Shared 'IPC')
 foreach($n in @('motor.ready','motor.info.json','motor.stop')){[IO.File]::WriteAllText((Join-Path $script:Shared ('IPC/'+$n)),'MOTOR_ATIVO_FICTICIO')}
 function Get-MotorConfig {return @{}}
 function Get-ConfigSharedRoot {param($RootDir,$Cfg)return $script:Shared}
 $db=$null;$networkLockStream=$null;$lockStream=$null
 & ([scriptblock]::Create($outer.Finally.Extent.Text.Trim().Substring(1,$outer.Finally.Extent.Text.Trim().Length-2)))
 if(Test-Path (Join-Path $script:Shared 'IPC/motor.ready')){throw 'P01 nao reproduzido'}
 if(-not(Test-Path (Join-Path $script:RootDir 'Dados/worker.stop'))){throw 'P01 worker nao reproduzido'}
 Finding P01 'Sem possuir nenhum lock, o finally apagou heartbeat/info/stop do motor ativo e criou worker.stop.'
 # P02: real repository-change function writes config before committing its rollback guard.
 Load-Functions 'Controle_Documentos.ps1' @('Apply-DocumentsRepositoryChange')
 $script:Modo='PRINCIPAL';$script:Main=[pscustomobject]@{Cursor='Default'}
 $script:DocumentsRoot=Join-Path $work 'ORIGEM';$script:OldRepository=$script:DocumentsRoot;$new=Join-Path $work 'NOVO'
 $script:Cfg=@{RepositorioDocumentos=$script:DocumentsRoot};$script:SharedRoot=$script:Shared;$script:Persisted=''
 function Normalize-DocumentsRepositoryPath([string]$p){return $p}
 function Test-DocumentsRepositoryAccess([string]$p){return $p}
 function Stop-MotorForRepositoryChange {return $true}
 function Write-SimpleConfig {param($Path,$Config)$script:Persisted=[string]$Config['RepositorioDocumentos']}
 function Write-DocumentsRepositoryPointer {param($Shared,$Path)throw 'FALHA_FICTICIA_AO_GRAVAR_PONTEIRO'}
 function Start-MotorAfterRepositoryChange {return $true}
 $err='';try{Apply-DocumentsRepositoryChange $new|Out-Null}catch{$err=$_.Exception.Message}
 if($script:Persisted -ne $new -or $script:DocumentsRoot -ne $script:OldRepository -or $err -notlike '*configuracao anterior foi restaurada*'){throw 'P02 nao reproduzido'}
 Finding P02 'Falha no ponteiro deixou Config.ini apontando para NOVO e DocumentsRoot em ORIGEM, mas o erro disse que restaurou a configuracao anterior.'
 # P03: candidate listing contract is correct, but the configured secondary destination is ignored.
 Load-Functions 'Controle_Documentos.ps1' @('Get-DatabaseBackupCandidates')
 $script:Cfg=@{BackupDocumentosDestino=(Join-Path $work 'BACKUP_CONFIGURADO')}
 $local=Join-Path $script:RootDir 'Dados/Backups';Ensure-Directory $local
 Ensure-Directory (Join-Path $script:Cfg.BackupDocumentosDestino 'Banco')
 $file='documentos_20261023_100000.db'
 [IO.File]::WriteAllText((Join-Path $local $file),'BANCO_FICTICIO_LOCAL')
 [IO.File]::WriteAllText((Join-Path $script:Cfg.BackupDocumentosDestino ('Banco/'+$file)),'BANCO_FICTICIO_SECUNDARIO')
 $g=Join-Path $work 'UNIDADE_G';Ensure-Directory $g
 if(Get-PSDrive G -ErrorAction SilentlyContinue){throw 'Teste nao toca em unidade G existente'}
 New-PSDrive -Name G -PSProvider FileSystem -Root $g|Out-Null
 try{$listed=@(Get-DatabaseBackupCandidates)}finally{Remove-PSDrive G}
 if($listed.Count -ne 1 -or $listed[0].Origem -ne 'LOCAL'){throw 'P03 nao reproduzido'}
 foreach($property in @('Data','Origem','Nome','Tamanho','Caminho','DataHora','Arquivo','MB')){if($null -eq $listed[0].PSObject.Properties[$property]){throw "Contrato incompleto: $property"}}
 Finding P03 'A lista retornou somente LOCAL; ignorou o banco existente em BackupDocumentosDestino/Banco. O contrato Data/Origem/Nome/Tamanho/Caminho e aliases passou.'
 # P04: real integrity audit with a valid existing hash but legacy missing size.
 Load-Functions 'Motor_Dados.ps1' @('Run-IntegrityAudit','Get-FileFingerprint','Copy-VerifiedFileAtomic','Get-NowIso')
 $script:DocumentsRoot=Join-Path $work 'DOCUMENTOS';Ensure-Directory $script:DocumentsRoot
 $script:BackupRoot=Join-Path $work 'BACKUP_PDF';Ensure-Directory $script:BackupRoot
 $pdf=Join-Path $script:DocumentsRoot 'exemplo.pdf';[IO.File]::WriteAllText($pdf,'%PDF-1.4 FICTICIO, NAO E DOCUMENTO REAL')
 $fp=Get-FileFingerprint $pdf
 $script:AuditRow=[pscustomobject]@{IdArquivo=1;IdDocumento=1;Tipo='RECEBIDO';NomeOriginal='exemplo.pdf';CaminhoRelativo='exemplo.pdf';HashSha256=$fp.Hash;TamanhoBytes=0}
 function Get-ProtectionConfig {return @{BackupAtivo=$true;BackupRoot=$script:BackupRoot;Autorreparo=$true}}
 function Rows-ToObjects($rows){return $rows}
 function Get-NormalizedManagedRelativePath([string]$p){return $p}
 function Resolve-ManagedDocumentPath {param($Shared,$Documents,$Relative)return Join-Path $Documents $Relative}
 function Get-BackupManagedDocumentPath {param($Backup,$Relative)return Join-Path $Backup $Relative}
 function Sql-Q($x){return "'"+([string]$x).Replace("'","''")+"'"}
 function Set-SystemMeta {param($Db,$Key,$Value)}
 function Get-IntegrityStatus {param($Db)return @{Total=1;Ok=1;Ausentes=0;HashDiferente=0;BackupOk=0}}
 $db=[pscustomobject]@{};$db|Add-Member ScriptMethod Query {param($sql)return @($script:AuditRow)};$db|Add-Member ScriptMethod Exec {param($sql)}
 $sum=Run-IntegrityAudit $db $script:SharedRoot $true
 $row=@(Import-Csv -LiteralPath (Join-Path $script:SharedRoot 'Auditoria/Integridade_ULTIMA.csv'))[0]
 if($row.Status -ne 'OK' -or $row.Backup -ne 'FALHA' -or [long]$row.TamanhoBytes -ne 0){throw 'P04 nao reproduzido'}
 Finding P04 'PDF com hash correto e tamanho legado zero foi considerado OK, mas o backup falhou por exigir tamanho zero; o tamanho nao foi preenchido.'
 # P05: execute the actual response-write block against disposable directories.
 $responseTry=$motor.FindAll({param($n)$n -is [Management.Automation.Language.TryStatementAst] -and $n.Body.Extent.Text.Contains("`$resp=Join-Path `$respDir (`$id+'.resp.json')")},$true)|Select-Object -Last 1
 if(-not $responseTry){throw 'Bloco de resposta ausente'}
 $respDir=Join-Path $work 'Respostas';Ensure-Directory $respDir
 $id='../fora_da_pasta';$respObj=@{Ok=$true;Result='FICTICIO';Error=''}
 & ([scriptblock]::Create($responseTry.Body.Extent.Text.Trim().Substring(1,$responseTry.Body.Extent.Text.Trim().Length-2)))
 if(-not(Test-Path -LiteralPath (Join-Path $work 'fora_da_pasta.resp.json'))){throw 'P05 nao reproduzido'}
 Finding P05 'Id com ../ levou a resposta JSON para fora de IPC/Respostas. Teste escreveu apenas um arquivo ficticio no diretorio descartavel.'
 # P06: post-COMMIT metadata failure must not delete PDFs belonging to committed rows.
 Load-Functions 'Motor_Dados.ps1' @('Process-RestoreTrashDocument','Get-SafePropertyValue','Get-LegacySafeString','Find-PreservedTrashFile','Get-OperationActor','Queue-PdfIndex')
 function Normalize-Key([string]$v){return $v.ToUpperInvariant()}
 function Normalize-Digits([string]$v){return [regex]::Replace($v,'\D','')}
 $key='DOC_00000001_20261023_120000';$trash=Join-Path $script:SharedRoot ('Lixeira/'+$key)
 $rel='DOC_00000001/Recebido/ficticio.pdf';$preserved=Join-Path $trash $rel
 Ensure-Directory (Split-Path $preserved -Parent)
 [IO.File]::WriteAllText($preserved,'%PDF-1.4 FICTICIO RESTAURACAO')
 $fp=Get-FileFingerprint $preserved
 $snap=@{Documento=@{IdDocumento=1;Numero='FICTICIO';Status='PENDENTE'};Respostas=@();Historico=@();Arquivos=@(@{IdArquivo=1;IdResposta=0;CaminhoRelativo=$rel;NomeOriginal='ficticio.pdf';HashSha256=$fp.Hash;TamanhoBytes=$fp.Size;Tipo='RECEBIDO'})}
 [IO.File]::WriteAllText((Join-Path $trash 'dossie_excluido.json'),($snap|ConvertTo-Json -Depth 8))
 # A directory at the marker name deterministically simulates a refused final marker write.
 Ensure-Directory (Join-Path $trash 'RESTAURADO.json')
 $script:DbCommitted=$false
 $db=[pscustomobject]@{};$db|Add-Member ScriptMethod Scalar {param($sql)return 0};$db|Add-Member ScriptMethod Exec {param($sql)if($sql -eq 'COMMIT;'){$script:DbCommitted=$true}}
 $errorText='';try{Process-RestoreTrashDocument $db $script:SharedRoot ([pscustomobject]@{trashKey=$key;usuario='TESTE'})|Out-Null}catch{$errorText=$_.Exception.Message}
 $target=Join-Path $script:DocumentsRoot $rel
 if(-not $script:DbCommitted -or (Test-Path -LiteralPath $target) -or -not $errorText){throw ('P06 nao reproduzido: '+$errorText)}
 Finding P06 'A restauracao de Lixeira confirmou COMMIT simulado; a falha real ao gravar RESTAURADO.json acionou catch e apagou o PDF recem-restaurado do repositorio ativo.'
 $results|ConvertTo-Json -Depth 5|Set-Content (Join-Path $RootAudit 'RESULTADOS_TESTES.json') -Encoding utf8
 $results|Format-Table -Wrap
 "TOTAL: $($results.Count) comportamentos reproduzidos; nenhum sistema real iniciado ou banco operacional acessado."
}finally{Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue}
