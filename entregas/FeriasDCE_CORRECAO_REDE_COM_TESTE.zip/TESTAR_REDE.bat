@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -File "%~dp0Testar_Compatibilidade_Rede.ps1" -AppRoot "%~dp0."
pause
