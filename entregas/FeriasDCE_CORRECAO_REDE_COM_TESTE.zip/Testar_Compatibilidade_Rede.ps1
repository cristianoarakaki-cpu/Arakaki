﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$AppRoot=$PSScriptRoot)
$ErrorActionPreference='Stop'
$relatorio=New-Object 'System.Collections.Generic.List[string]'
function Write-DiagLog {
 param($Message,$Level='INFO',$ErrorRecord)
 $linha="[$Level] $Message"
 $relatorio.Add($linha)
 Write-Host $linha
}
function Get-TextSha256([string]$value){
 $sha=[Security.Cryptography.SHA256]::Create()
 try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($value)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Invoke-DatabaseFileReplace([string]$Source,[string]$Destination,[string]$Backup){
    [IO.File]::Replace($Source,$Destination,$Backup)
}

function Invoke-DatabaseAtomicRename([string]$Source,[string]$Destination,[string]$ExpectedOldHash){
    if($env:OS -ne 'Windows_NT'){throw 'A alternativa de renomeacao atomica exige Windows.'}
    # O rename troca a identidade do arquivo. Nao alterar silenciosamente proprietario/grupo/DACL.
    $sections=[Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Group -bor [Security.AccessControl.AccessControlSections]::Access
    $srcAcl=Get-Acl -LiteralPath $Source -ErrorAction Stop
    $dstAcl=Get-Acl -LiteralPath $Destination -ErrorAction Stop
    $srcSecurity=$srcAcl.GetSecurityDescriptorSddlForm($sections)
    $dstSecurity=$dstAcl.GetSecurityDescriptorSddlForm($sections)
    if($srcSecurity -ne $dstSecurity){
        throw 'Renomeacao alternativa cancelada: proprietario, grupo ou permissoes do temporario diferem da base. Nao foram modificadas permissoes.'
    }
    $sensitive=[IO.FileAttributes]::ReadOnly -bor [IO.FileAttributes]::Hidden -bor [IO.FileAttributes]::System -bor [IO.FileAttributes]::Encrypted -bor [IO.FileAttributes]::Compressed
    $srcAttributes=[IO.File]::GetAttributes($Source)
    $dstAttributes=[IO.File]::GetAttributes($Destination)
    if(($dstAttributes -band [IO.FileAttributes]::ReadOnly) -ne 0){throw 'A base esta marcada como somente leitura; nao sera alterada.'}
    if(($srcAttributes -band $sensitive) -ne ($dstAttributes -band $sensitive)){
        throw 'Renomeacao alternativa cancelada: atributos protegidos/compressao/criptografia diferem entre temporario e base.'
    }
    if((Get-TextSha256 ([IO.File]::ReadAllText($Destination,[Text.Encoding]::UTF8))) -ne $ExpectedOldHash){
        throw 'A base mudou durante a preparacao da renomeacao. Gravacao cancelada para preservar alteracoes externas.'
    }
    if(-not ('FeriasDCE.AtomicFileNative' -as [type])){
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
namespace FeriasDCE {
    public static class AtomicFileNative {
        [DllImport("kernel32.dll", EntryPoint="MoveFileExW", CharSet=CharSet.Unicode, SetLastError=true, ExactSpelling=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool MoveFileEx(string existingName, string newName, uint flags);
    }
}
"@ -ErrorAction Stop
    }
    if((Get-TextSha256 ([IO.File]::ReadAllText($Destination,[Text.Encoding]::UTF8))) -ne $ExpectedOldHash){
        throw 'A base mudou antes da renomeacao. Gravacao cancelada.'
    }
    # REPLACE_EXISTING | WRITE_THROUGH. Sem COPY_ALLOWED e sem apagar primeiro o destino.
    if(-not [FeriasDCE.AtomicFileNative]::MoveFileEx($Source,$Destination,9)){
        $code=[Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw [ComponentModel.Win32Exception]::new($code,('A rede/Windows recusou a renomeacao com substituicao (codigo '+$code+').'))
    }
}

function Invoke-DatabaseCompatibleReplace([string]$Source,[string]$Destination,[string]$Backup){
    # Chamado sob o lock da base. Captura o estado ANTES de File.Replace para detectar falhas parciais.
    $oldHash=Get-TextSha256 ([IO.File]::ReadAllText($Destination,[Text.Encoding]::UTF8))
    $newHash=Get-TextSha256 ([IO.File]::ReadAllText($Source,[Text.Encoding]::UTF8))
    try {
        Invoke-DatabaseFileReplace $Source $Destination $Backup
        Write-DiagLog 'Substituicao concluida por File.Replace.' 'INFO'
        return
    } catch {
        $replaceError=$_
        $baseError=$_.Exception.GetBaseException()
        $nativeCode=$baseError.HResult -band 0xffff
        if($baseError -isnot [UnauthorizedAccessException] -and $nativeCode -notin @(1,5,50)){
            throw
        }
        # Nao continuar se Replace moveu algum arquivo parcialmente ou houve alteracao externa.
        if(-not [IO.File]::Exists($Source) -or -not [IO.File]::Exists($Destination)){throw $replaceError}
        if((Get-TextSha256 ([IO.File]::ReadAllText($Destination,[Text.Encoding]::UTF8))) -ne $oldHash){throw $replaceError}
        if((Get-TextSha256 ([IO.File]::ReadAllText($Source,[Text.Encoding]::UTF8))) -ne $newHash){throw $replaceError}
        $safetyBackup=$Backup
        if([string]::IsNullOrWhiteSpace($safetyBackup)){
            $safetyBackup=$Destination+'.antes_rollback.'+[guid]::NewGuid().ToString('N')
        }
        if(-not [IO.File]::Exists($safetyBackup)){
            [IO.File]::Copy($Destination,$safetyBackup,$false)
        }
        if((Get-TextSha256 ([IO.File]::ReadAllText($safetyBackup,[Text.Encoding]::UTF8))) -ne $oldHash){
            throw 'Backup anterior diverge da base. Renomeacao alternativa cancelada.'
        }
        Write-DiagLog ('File.Replace recusado (codigo '+$nativeCode+'). Tentando renomeacao com substituicao, sem copia sobre a base. Backup: '+$safetyBackup) 'WARN'
        Invoke-DatabaseAtomicRename $Source $Destination $oldHash
        Write-DiagLog 'Substituicao concluida por renomeacao Windows (MoveFileEx), mantendo validacao posterior e lock.' 'INFO'
    }
}


$prefixo=Join-Path ([IO.Path]::GetFullPath($AppRoot)) ('Dados\.teste_rename_ferias_'+[guid]::NewGuid().ToString('N'))
$src=$prefixo+'_nova.tmp';$dest=$prefixo+'_anterior.tmp';$bk=$prefixo+'_backup.tmp'
$report=Join-Path ([IO.Path]::GetTempPath()) ('Teste_Rename_Ferias_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N')+'.txt')
function Criar-Teste([string]$p,[string]$t){
 $f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$b=[Text.Encoding]::UTF8.GetBytes($t);$f.Write($b,0,$b.Length)}finally{$f.Dispose()}
}
try {
 Write-DiagLog ('Teste descartavel em: '+$AppRoot)
 Write-DiagLog 'O JSON real nao sera lido nem alterado. Nenhuma permissao ou configuracao de seguranca sera modificada.'
 Criar-Teste $src '{"teste":"novo"}'
 Criar-Teste $dest '{"teste":"anterior"}'
 Invoke-DatabaseCompatibleReplace $src $dest $bk
 if([IO.File]::ReadAllText($dest) -ne '{"teste":"novo"}' -or [IO.File]::ReadAllText($bk) -ne '{"teste":"anterior"}'){
  throw 'Conteudo de teste ou backup diverge do esperado.'
 }
 Write-DiagLog 'PASSOU: substituicao de descartaveis com backup validada. Isso nao comprova permissao sobre o JSON existente; o programa tambem verificara sua seguranca antes de usar a alternativa.'
} catch {
 Write-DiagLog ('NAO PASSOU: '+$_.Exception.Message) 'ERROR'
 Write-DiagLog 'Nao substitua o script para forcar gravacao. Envie este relatorio para analisar o bloqueio.' 'WARN'
} finally {
 foreach($p in @($src,$dest,$bk)){
  try {if([IO.File]::Exists($p)){[IO.File]::Delete($p)}}catch{Write-DiagLog ('Descartavel nao removido: '+$p+' | '+$_.Exception.Message) 'WARN'}
 }
 try {
  Criar-Teste $report ($relatorio -join [Environment]::NewLine)
  Write-Host ('RELATORIO: '+$report)
 } catch {Write-Warning ('Falha ao salvar relatorio: '+$_.Exception.Message)}
}
