const servidores=[];
const registrosCentral=__REGISTROS__;
function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function valorDiretoria(){
  const el=document.getElementById('configDiretoria');
  return el?String(el.value||'').trim():'DCE';
}
function setorComDiretoria(setor){
  const s=String(setor||'').trim();
  const d=valorDiretoria();
  if(!d) return s;
  if(!s) return d;
  return s+' / '+d;
}
function atualizarDiretoria(){
  const p=document.getElementById('setorPrincipalCabecalho');
  if(p) p.textContent=setorComDiretoria(p.dataset.setor||'');
  renderFolhasAdicionais();
}
function selecionados(){return servidores.filter((s,i)=>{const c=document.getElementById('srv_'+i);return c&&c.checked;});}
function renderLista(){
  const l=document.getElementById('listaServidores');
  l.innerHTML='';
  servidores.forEach((s,i)=>{
    const d=document.createElement('label');
    d.className='item-servidor';
    d.innerHTML='<input type="checkbox" id="srv_'+i+'" '+(s.selecionado?'checked':'')+' onchange="renderPlanilha()">'
      +'<span class="item-nome">'+esc(s.nome)+'</span>'
      +'<span>CP '+esc(s.cp)+'</span>'
      +'<span>'+esc(s.entrada)+'–'+esc(s.saida)+'</span>';
    l.appendChild(d);
  });
}
function renderPlanilha(){
  const a=selecionados();
  const qtd=document.getElementById('qtdSelecionados');
  const corpoFreq=document.getElementById('corpoFrequencia');
  const corpoJust=document.getElementById('corpoJustificativa');
  if(qtd) qtd.textContent=a.length;
  if(!corpoFreq||!corpoJust) return;
  corpoFreq.innerHTML=a.map(s=>
    '<tr class="linha-servidor">'
    +'<td class="matricula-servidor">'+esc(s.matricula)+'</td>'
    +'<td class="cp-servidor">'+esc(s.cp)+'</td>'
    +'<td class="nome-servidor">'+esc(s.nome)+'</td>'
    +'<td class="centro">'+esc(s.carga)+'</td>'
    +'<td class="centro cargo-servidor">'+esc(s.cargo)+'</td>'
    +'<td class="centro">'+esc(s.entrada)+'</td>'
    +'<td class="centro">'+esc(s.saida)+'</td>'
    +'<td class="centro horario-realizado">&nbsp;</td>'
    +'<td class="centro horario-realizado">&nbsp;</td>'
    +'<td class="rubrica-servidor">&nbsp;</td>'
    +'</tr>'
  ).join('');
  corpoJust.innerHTML=a.map(s=>
    '<tr><td>'+esc(s.cp)+'</td><td>'+esc(s.justificativa)+'</td></tr>'
  ).join('');
}
function marcarTodos(v){
  document.querySelectorAll('#listaServidores input[type=checkbox]').forEach(c=>c.checked=v);
  renderPlanilha();
}
function imprimirPlanilha(){
  const atuais=selecionados();
  const adicionais=centralSelecionados();
  if(atuais.length===0 && adicionais.length===0){
    alert('Selecione pelo menos um servidor para gerar a planilha.');
    return;
  }
  if(document.getElementById('corpoFrequencia')) renderPlanilha();
  renderFolhasAdicionais();
  setTimeout(()=>window.print(),50);
}
function alternarCentral(){
  const c=document.getElementById('conteudoCentral');
  c.style.display=(c.style.display==='none'?'block':'none');
}
function normaliza(v){return String(v==null?'':v).toLocaleLowerCase('pt-BR');}
function centralFiltrados(){
  const fi=document.getElementById('filtroDataInicio').value;
  const ff=document.getElementById('filtroDataFim').value;
  const brutoSetor=document.getElementById('filtroSetor').value;
  const setores=brutoSetor.split(',').map(t=>normaliza(t).trim()).filter(t=>t.length>0);
  const bruto=document.getElementById('filtroNome').value;
  const termos=bruto.split(',').map(t=>normaliza(t).trim()).filter(t=>t.length>0);
  return registrosCentral.map((r,i)=>({...r,_i:i})).filter(r=>{
    const nome=normaliza(r.nome);
    const cp=normaliza(r.cp);
    const setor=normaliza(r.setor);
    const atendeSetor=(setores.length===0)||setores.some(t=>setor.includes(t));
    const atendeNomeCp=(termos.length===0)||termos.some(t=>nome.includes(t)||cp.includes(t));
    const dataRegistro=String(r.dataIso||'');
    return (!fi||(dataRegistro!==''&&dataRegistro>=fi)) &&
           (!ff||(dataRegistro!==''&&dataRegistro<=ff)) &&
           atendeSetor &&
           atendeNomeCp;
  });
}
function renderCentral(){
  const tb=document.getElementById('corpoCentral');
  const lista=centralFiltrados();
  tb.innerHTML=lista.map(r=>
    '<tr data-i="'+r._i+'">'
    +'<td><input type="checkbox" id="cen_'+r._i+'" '+(r.adicionado?'checked':'')+' onchange="toggleCentral('+r._i+',this.checked)"></td>'
    +'<td>'+esc(r.data)+'</td>'
    +'<td>'+esc(r.setor)+'</td>'
    +'<td>'+esc(r.cp)+'</td>'
    +'<td>'+esc(r.nome)+'</td>'
    +'<td>'+esc(r.cargo)+'</td>'
    +'<td>'+esc(r.entrada)+'–'+esc(r.saida)+'</td>'
    +'</tr>'
  ).join('');
  atualizaResumoCentral();
}
function filtrarCentral(){renderCentral();}
function limparFiltrosCentral(){
  document.getElementById('filtroDataInicio').value='';
  document.getElementById('filtroDataFim').value='';
  document.getElementById('filtroSetor').value='';
  document.getElementById('filtroNome').value='';
  renderCentral();
}
function toggleCentral(i,v){
  registrosCentral[i].adicionado=v;
  atualizaResumoCentral();
  renderFolhasAdicionais();
}
function selecionarVisiveisCentral(v){
  centralFiltrados().forEach(r=>registrosCentral[r._i].adicionado=v);
  renderCentral();
  renderFolhasAdicionais();
}
function centralSelecionados(){return registrosCentral.filter(r=>r.adicionado);}
function chaveGrupo(r){return r.dataIso+'|'+r.setor;}
function gruposAdicionais(){
  const m=new Map();
  centralSelecionados().forEach(r=>{
    const k=chaveGrupo(r);
    if(!m.has(k)){
      m.set(k,{
        data:r.data,
        dataIso:r.dataIso,
        dataExtenso:r.dataExtenso,
        mes:r.mes,
        ano:r.ano,
        setor:r.setor,
        itens:[]
      });
    }
    m.get(k).itens.push(r);
  });
  return [...m.values()].sort((a,b)=>(a.dataIso+a.setor).localeCompare(b.dataIso+b.setor));
}
function atualizaResumoCentral(){
  const sel=centralSelecionados();
  document.getElementById('qtdCentralSelecionados').textContent=sel.length;
  const gs=gruposAdicionais();
  document.getElementById('resumoGrupos').innerHTML=gs.length
    ? '<b>Planilhas adicionais:</b> '+gs.map(g=>esc(g.data)+' — '+esc(g.setor)+' ('+g.itens.length+')').join(' &nbsp; | &nbsp; ')
    : '<span class="muted">Nenhuma planilha adicional selecionada.</span>';
}
function folhaHtml(g){
  const linhas=g.itens.map(s=>
    '<tr class="linha-servidor">'
    +'<td class="matricula-servidor">'+esc(s.matricula)+'</td>'
    +'<td class="cp-servidor">'+esc(s.cp)+'</td>'
    +'<td class="nome-servidor">'+esc(s.nome)+'</td>'
    +'<td class="centro">'+esc(s.carga)+'</td>'
    +'<td class="centro cargo-servidor">'+esc(s.cargo)+'</td>'
    +'<td class="centro">'+esc(s.entrada)+'</td>'
    +'<td class="centro">'+esc(s.saida)+'</td>'
    +'<td class="centro horario-realizado">&nbsp;</td>'
    +'<td class="centro horario-realizado">&nbsp;</td>'
    +'<td class="rubrica-servidor">&nbsp;</td>'
    +'</tr>'
  ).join('');

  const just=g.itens.map(s=>
    '<tr><td>'+esc(s.cp)+'</td><td>'+esc(s.justificativa)+'</td></tr>'
  ).join('');

  let h='';
  h+='<main class="folha folha-adicional page-break">';
  h+='<div class="anexo">ANEXO II AO DECRETO Nº 12.755, DE 22 DE MAIO DE 2009.</div>';
  h+='<table class="cabecalho-oficial"><tr>';
  h+='<td class="logo-oficial"><img src="brasao.png" alt="Brasão do Estado"></td>';
  h+='<td class="estado-oficial">Estado de Mato Grosso do Sul</td>';
  h+='<td class="titulo-oficial">PLANILHA DE FREQUÊNCIA NO PLANTÃO EXTRA</td>';
  h+='</tr></table>';

  h+='<table class="identificacao-oficial">';
  h+='<tr><td colspan="6"><b>Órgão ou Entidade:</b>&nbsp; FUNDAÇÃO SERVIÇOS DE SAÚDE</td></tr>';
  h+='<tr><td colspan="4"><b>Unidade:</b>&nbsp; HOSPITAL REGIONAL DE MATO GROSSO DO SUL</td>';
  h+='<td colspan="2"><b>Setor:</b>&nbsp; '+esc(setorComDiretoria(g.setor))+'</td></tr>';
  h+='<tr><td colspan="2"><b>Mês:</b>&nbsp; '+esc(g.mes)+'</td>';
  h+='<td colspan="2"><b>Ano:</b>&nbsp; '+esc(g.ano)+'</td>';
  h+='<td colspan="2"><b>Dia:</b>&nbsp; '+esc(g.data)+'</td></tr>';
  h+='</table>';

  h+='<div class="bloco-central">';
  h+='<table class="frequencia">';
  h+='<colgroup>'
    +'<col class="c-matricula"><col class="c-cp"><col class="c-nome"><col class="c-carga"><col class="c-cargo">'
    +'<col class="c-inicio"><col class="c-termino"><col class="c-real-inicio"><col class="c-real-termino"><col class="c-rubrica">'
    +'</colgroup>';
  h+='<thead><tr>'
    +'<th class="h-matricula" rowspan="2">Matrícula</th>'
    +'<th class="h-cp" rowspan="2">Cartão<br>de<br>Ponto</th>'
    +'<th rowspan="2">Nome dos Servidores</th>'
    +'<th rowspan="2">Carga<br>horária<br>semanal</th>'
    +'<th rowspan="2">Cargo/Função</th>'
    +'<th colspan="2">Horário Plantão</th>'
    +'<th colspan="2">Horário Realizado</th>'
    +'<th rowspan="2">Rubrica do<br>Servidor</th>'
    +'</tr><tr><th>Início</th><th>Término</th><th>Início</th><th>Término</th></tr></thead>';
  h+='<tbody>'+linhas+'</tbody></table>';

  h+='<div class="declaracao">Assumimos inteira responsabilidade sobre a veracidade das informações aqui expressas, sob as penas da lei.</div>';
  h+='<div class="data-local">Campo Grande&nbsp;&nbsp;&nbsp;&nbsp;'+esc(g.dataExtenso)+'</div>';
  h+='<div class="area-assinaturas">';
  h+='<div class="assinatura esquerda"><div class="linha-assinatura"></div><div>Responsável pela Unidade</div></div>';
  h+='<div class="assinatura direita"><div class="linha-assinatura"></div><div>Chefia Imediata</div></div>';
  h+='</div></div>';

  h+='<table class="justificativa-oficial">';
  h+='<colgroup><col class="c-just-cp"><col class="c-just-texto"></colgroup>';
  h+='<thead><tr><th>CP</th><th>JUSTIFICATIVA</th></tr></thead>';
  h+='<tbody>'+just+'</tbody></table>';
  h+='</main>';
  return h;
}
function renderFolhasAdicionais(){
  const gs=gruposAdicionais();
  document.getElementById('folhasAdicionais').innerHTML=gs.map(g=>folhaHtml(g)).join('');
  atualizaResumoCentral();
}
document.addEventListener('DOMContentLoaded',()=>{
  renderLista();
  renderPlanilha();
  renderCentral();
  renderFolhasAdicionais();
  atualizarDiretoria();
});
