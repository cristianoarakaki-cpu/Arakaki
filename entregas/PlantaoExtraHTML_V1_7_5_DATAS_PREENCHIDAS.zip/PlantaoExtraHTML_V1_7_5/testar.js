const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname;const template=fs.readFileSync(root+'/script_gerado.js','utf8');
const records=[
 {dataIso:'2026-10-19',nome:'Antes',cp:'100',setor:'Cardiologia'},
 {dataIso:'2026-10-20',nome:'Ana',cp:'123',setor:'Cardiologia'},
 {dataIso:'2026-10-24',nome:'Beatriz',cp:'456',setor:'UTI'},
 {dataIso:'2026-10-30',nome:'Carlos',cp:'555',setor:'UTI'},
 {dataIso:'2026-10-31',nome:'Depois',cp:'999',setor:'Outro'},
 {dataIso:'',nome:'Sem data',cp:'000',setor:'Outro'}
].map(r=>({...r,adicionado:false,data:r.dataIso,matricula:r.cp,carga:'40',cargo:'Enfermeiro',entrada:'07:00',saida:'19:00',justificativa:'Ficticio',mes:'OUTUBRO',ano:'2026',dataExtenso:r.dataIso}));
const results=[];
function boot(ini,fim){const els={};let loaded;const make=()=>({value:'',innerHTML:'',textContent:'',style:{display:'block'},dataset:{},appendChild(){}});
 const document={getElementById(id){return els[id]||(els[id]=make())},createElement:()=>make(),querySelectorAll:()=>[],addEventListener(event,fn){assert.equal(event,'DOMContentLoaded');loaded=fn;}};
 document.getElementById('filtroDataInicio').value=ini;document.getElementById('filtroDataFim').value=fim;
 document.getElementById('configDiretoria').value='DCE';let printed=0;
 const ctx=vm.createContext({document,window:{print(){printed++}},setTimeout:fn=>fn(),alert:m=>{throw Error(m)}});
 vm.runInContext(template.replace('__REGISTROS__',JSON.stringify(records)),ctx);loaded();
 return {els,run:s=>vm.runInContext(s,ctx),names:()=>Array.from(vm.runInContext('centralFiltrados().map(r=>r.nome)',ctx)),printed:()=>printed};
}
let x=boot('2026-10-24','2026-10-24');assert.deepEqual(x.names(),['Beatriz']);assert(x.els.corpoCentral.innerHTML.includes('Beatriz'));assert(!x.els.corpoCentral.innerHTML.includes('Ana'));results.push('Data especifica: HTML inicial e filtragem mostram a data escolhida.');
x=boot('2026-10-20','2026-10-30');assert.deepEqual(x.names(),['Ana','Beatriz','Carlos']);results.push('Intervalo inclusivo: ambas as extremidades e dia intermediario; datas externas e ausentes excluidas.');
x.els.filtroSetor.value='cardio, uti';x.els.filtroNome.value='123, beatriz';assert.deepEqual(x.names(),['Ana','Beatriz']);results.push('Setor multiplo e Nome/CP multiplo continuam combinados com as datas.');
x.run('selecionarVisiveisCentral(true)');assert.equal(x.run('centralSelecionados().length'),2);assert.equal(x.run('gruposAdicionais().length'),2);x.run('imprimirPlanilha()');assert.equal(x.printed(),1);results.push('Selecao de visiveis, agrupamento Setor+Data e chamada de impressao preservados.');
x.run('limparFiltrosCentral()');assert.equal(x.els.filtroDataInicio.value,'');assert.equal(x.els.filtroDataFim.value,'');assert.equal(x.names().length,6);assert.equal(x.run('centralSelecionados().length'),2);results.push('Limpar filtros esvazia as duas datas e filtros textuais, sem perder selecoes.');
x=boot('2026-10-30','2026-10-20');assert.deepEqual(x.names(),[]);results.push('Intervalo invertido nao apresenta registros fora dos limites.');
x=boot('','2026-10-20');assert.deepEqual(x.names(),['Antes','Ana']);results.push('Somente data final: respeita o limite e exclui registro sem data.');
x=boot('2026-10-30','');assert.deepEqual(x.names(),['Carlos','Depois']);results.push('Somente data inicial: respeita o limite e exclui registro sem data.');
x=boot('2026-11-03','2026-11-03');assert.deepEqual(x.names(),[]);results.push('Data sem registros: tabela vazia sem erro na inicializacao.');
fs.writeFileSync(root+'/RESULTADO_JAVASCRIPT.txt',results.join('\n')+'\n');console.log(results.join('\n'));console.log('TOTAL: '+results.length+' verificacoes aprovadas; DOM simulado, Access nao executado.');
