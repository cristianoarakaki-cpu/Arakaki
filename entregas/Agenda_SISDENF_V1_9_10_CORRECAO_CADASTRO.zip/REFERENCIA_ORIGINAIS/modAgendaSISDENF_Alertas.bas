Attribute VB_Name = "modAgendaSISDENF_Alertas"
Option Compare Database
Option Explicit

Private Const INICIO_ALERTAS As Date = #10/17/2026#

'Consulta somente: nunca altera Lida, Agenda ou Ciencia.
'Eventos a partir de 17/10/2026 que ja iniciaram ate a data atual
'e ainda nao foram confirmados pelo usuario Windows.
Public Function AgendaAlerta_Quantidade(Optional ByVal usuario As String = "") As Long
    On Error GoTo Falha
    Dim db As DAO.Database
    Dim q As DAO.QueryDef
    Dim rs As DAO.Recordset
    Dim sql As String
    If Len(Trim$(usuario)) = 0 Then usuario = Environ$("USERNAME")
    If Len(Trim$(usuario)) = 0 Then Err.Raise vbObjectError + 2001, , "Login Windows indisponivel."
    sql = "PARAMETERS pInicio DATETIME, pAte DATETIME, pUsuario TEXT(100); " & _
          "SELECT Count(*) AS Qtde FROM T_Agendamento AS A " & _
          "WHERE A.[Data] >= [pInicio] AND A.[Data] < [pAte] " & _
          "AND A.[Hora] Is Not Null " & _
          "AND NOT EXISTS (SELECT C.IDCiencia FROM T_AgendaCiencia AS C " & _
          "WHERE C.IDAgendamento=A.ID AND C.Usuario=[pUsuario]);"
    Set db = CurrentDb
    Set q = db.CreateQueryDef("", sql)
    q.Parameters("pInicio") = INICIO_ALERTAS
    q.Parameters("pAte") = DateAdd("d", 1, Date)
    q.Parameters("pUsuario") = Left$(usuario, 100)
    Set rs = q.OpenRecordset(dbOpenSnapshot)
    AgendaAlerta_Quantidade = CLng(Nz(rs!Qtde, 0))
Limpar:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    Set rs = Nothing: Set q = Nothing: Set db = Nothing
    Exit Function
Falha:
    Dim numero As Long, descricao As String
    numero = Err.Number: descricao = Err.Description
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    Set rs = Nothing: Set q = Nothing: Set db = Nothing
    On Error GoTo 0
    Err.Raise numero, "AgendaAlerta_Quantidade", descricao
End Function

'Janela informativa simples; somente apresenta resumo. A ciencia e registrada
'exclusivamente pelo botao Confirmar ciencia da agenda HTML.
Public Function AgendaAlerta_Resumo(Optional ByVal usuario As String = "", Optional ByVal maxItens As Long = 5) As String
    On Error GoTo Falha
    Dim db As DAO.Database, q As DAO.QueryDef, rs As DAO.Recordset
    Dim sql As String, msg As String, n As Long, Total As Long
    If Len(Trim$(usuario)) = 0 Then usuario = Environ$("USERNAME")
    If Len(Trim$(usuario)) = 0 Then Err.Raise vbObjectError + 2002, , "Login Windows indisponivel."
    If maxItens < 1 Then maxItens = 1
    If maxItens > 10 Then maxItens = 10
    Total = AgendaAlerta_Quantidade(usuario)
    If Total = 0 Then
        AgendaAlerta_Resumo = "Nenhum compromisso aguardando ciencia."
        Exit Function
    End If
    sql = "PARAMETERS pInicio DATETIME, pAte DATETIME, pUsuario TEXT(100); " & _
          "SELECT A.ID, A.[Data], A.[Hora], A.[Agenda] FROM T_Agendamento AS A " & _
          "WHERE A.[Data] >= [pInicio] AND A.[Data] < [pAte] " & _
          "AND A.[Hora] Is Not Null " & _
          "AND NOT EXISTS (SELECT C.IDCiencia FROM T_AgendaCiencia AS C " & _
          "WHERE C.IDAgendamento=A.ID AND C.Usuario=[pUsuario]) " & _
          "ORDER BY A.[Data] DESC, A.[Hora] ASC, A.ID ASC;"
    Set db = CurrentDb: Set q = db.CreateQueryDef("", sql)
    q.Parameters("pInicio") = INICIO_ALERTAS
    q.Parameters("pAte") = DateAdd("d", 1, Date)
    q.Parameters("pUsuario") = Left$(usuario, 100)
    Set rs = q.OpenRecordset(dbOpenSnapshot)
    msg = CStr(Total) & " compromisso(s) aguardando ciencia:" & vbCrLf & vbCrLf
    Do While Not rs.EOF And n < maxItens
        msg = msg & Format$(rs.Fields("Data").Value, "dd/mm/yyyy") & " " & _
              Format$(rs.Fields("Hora").Value, "hh:nn") & " - " & _
              Left$(Replace(Replace(Nz(rs.Fields("Agenda").Value, ""), vbCr, " "), vbLf, " "), 120) & vbCrLf
        n = n + 1: rs.MoveNext
    Loop
    If Total > n Then msg = msg & vbCrLf & "... e mais " & (Total - n) & " compromisso(s)."
    AgendaAlerta_Resumo = msg
Limpar:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    Set rs = Nothing: Set q = Nothing: Set db = Nothing
    Exit Function
Falha:
    Dim numero As Long, descricao As String
    numero = Err.Number: descricao = Err.Description
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    Set rs = Nothing: Set q = Nothing: Set db = Nothing
    On Error GoTo 0
    Err.Raise numero, "AgendaAlerta_Resumo", descricao
End Function
