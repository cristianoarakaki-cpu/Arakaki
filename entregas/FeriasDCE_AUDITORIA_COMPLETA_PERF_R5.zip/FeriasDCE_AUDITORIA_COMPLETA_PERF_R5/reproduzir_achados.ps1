﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$source=Join-Path $PSScriptRoot 'Fonte/FeriasDCE.ps1'
if((Get-FileHash $source -Algorithm SHA256).Hash -ne '11E11DB8293C66367F023E773C22A899173D3B036CA9268C8AAFAB8B52640430'){throw 'Fonte diferente da avaliada; confira a versao antes de interpretar os resultados.'}
$t=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($source,[ref]$t,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
foreach($fn in $ast.EndBlock.Statements){if($fn -is [Management.Automation.Language.FunctionDefinitionAst]){. ([scriptblock]::Create($fn.Extent.Text))}}
# Only message boxes are simulated; no real interface or production storage is started.
Add-Type @'
namespace System.Windows.Forms {
 public enum DialogResult {None,OK,Cancel,Yes,No}
 public enum MessageBoxButtons {OK,YesNo,YesNoCancel}
 public enum MessageBoxIcon {Information,Warning,Question,Error}
 public static class MessageBox { public static DialogResult Show(params object[] values){return DialogResult.Yes;} }
}
'@
function Write-DiagLog {param($Message,$Level,$ErrorRecord)}
function Save-Database {$script:AuditSaves++;return $true}
function Backup-AntesAcao {param($prefixo)return 'BACKUP_SIMULADO'}
function Confirmar-ResetDuplo {param($titulo,$descricao,$digitado)return $true}
function Refresh-AllAfterMaintenance {}
function Reset-Fixture {
 $script:Config=[pscustomobject]@{total_enfermeiros_planejamento=189;meses_restritos=@();limites_especiais_mensais=@{};periodos=@('DIURNO');setores=@('A','B');grupo_analise_setores=@();grupo_chefia_setores=@();grupo_chefia_servidores=@();grupos_chefia=@();limites_setor_periodo=@();limites_grupo_chefia_periodo=@();historico_3_anos_importado=$false;ferias_fixas_2027_importadas=$true;ultima_importacao_fixas='';ultima_importacao_historico='';ultimo_backup_lote='';ultimo_manifesto_lote='';servidores_excluidos=@();importacao_lancamentos_anulados=@();feriados_recorrentes=@();feriados_especificos=@();percentual_meses_restritos=10}
 $script:Records=@();$script:HistoricoFerias=@();$script:PlanejGrupoSelecionado='TODOS';$script:PlanejSetoresSelecionados=@();$script:PlanejPeriodosSelecionados=@();$script:cmbPlanejChefia=[pscustomobject]@{SelectedItem='TODOS'};$script:LoadedDbHash='sintetico';$script:PlanejCriticoMeses=@();$script:PlanejOverlapCache=@{};$script:PlanejChefiaOverlapCache=@{};$script:AuditSaves=0
}
function New-Record([int]$Id=1,[string]$Mat='TESTE1') {
 $r=[pscustomobject]@{id=$Id;matricula=$Mat;nome=('Servidor ficticio '+$Id);setor='A';periodo='DIURNO';aquisitivo_inicio='2026-01-01';aquisitivo_fim='2026-12-31'}
 [void](Initialize-RecordDefaults $r);return $r
}
function New-Common([string]$Ini,[int]$Days=30){$o=New-EmptyOptionObject;$o.tipo='30 DIAS';$o.inicio1=$Ini;$o.fim1=([datetime]::ParseExact($Ini,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)).AddDays($Days-1).ToString('yyyy-MM-dd');return $o}
function Handler([string]$Function,[string]$Prefix){
 $scope=if($Function){$ast.EndBlock.Statements|Where-Object {$_.Name -eq $Function}}else{$ast}
 $node=$scope.Find({param($n)$n -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $n.Extent.Text.StartsWith($Prefix)},$true)
 if(-not $node){throw "Handler ausente: $Function $Prefix"}
 return [scriptblock]::Create($node.Arguments[0].ScriptBlock.Extent.Text.Substring(1,$node.Arguments[0].ScriptBlock.Extent.Text.Length-2))
}
$results=[Collections.Generic.List[object]]::new()
function Finding($Id,$Actual,$Expected,$Evidence){$results.Add([pscustomobject]@{id=$Id;observado=$Actual;esperado=$Expected;evidencia=$Evidence})}
Reset-Fixture
$r=New-Record;$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-01-01';$r.fixo_fim='2027-01-15'
$r|Add-Member NoteProperty fixos_adicionais @([pscustomobject]@{inicio='2027-03-01';fim='2027-03-15'})
$script:Records=@($r)
$institutional=Get-ContagemInstitucionalAprovadaMes 2027 3;$months=@(Get-MesesPlanejamentoRegistro $r 2027)
if($institutional -ne 0 -or $months -notcontains 3){throw 'A01 nao reproduzido'}
Finding A01 "Marco institucional=$institutional; grade inclui marco=$($months -contains 3)" 'Marco institucional=0,5' 'Get-OpcaoPlanejamento + Get-OptionBlocksObjeto descartam inicio2 das fixas'
Reset-PlanejamentoAtual|Out-Null
if(@(Get-FixasAdicionais $r).Count -ne 1){throw 'A02 nao reproduzido'}
$ghost=@(Get-EntradasConferenciaSetor $false)
if($ghost.Count -ne 1 -or $ghost[0].Situacao -ne 'FIXA'){throw 'A02 ghost nao reproduzido'}
Finding A02 'Reset zerou principal e bloqueio, mas manteve 1 adicional; conferencia ainda o apresenta como FIXA' 'Zero parcelas fixas apos zerar planejamento' 'Reset real com Save/backup/refresh simulados; consulta real apos reset'
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-01-17';$r.opcao1.fr_inicio='2027-02-16';$r.opcao1.fr_fim='2027-03-07';$r.opcao_aprovada=1;$r.fr_opcao_aprovada=1;$script:Records=@($r)
if(Validate-Option $r.opcao1 'teste' $r.aquisitivo_fim){throw 'Fixture A03 invalida'}
$reportFn=$ast.EndBlock.Statements|Where-Object {$_.Name -eq 'Show-RelatorioAceitesEnfermagem'}
$try=$reportFn.Body.EndBlock.Statements|Where-Object {$_ -is [Management.Automation.Language.TryStatementAst]}|Select-Object -First 1
$prefix=@();foreach($statement in $try.Body.Statements){if($statement.Extent.Text.StartsWith('$nominaisJson=')){break};$prefix+=$statement.Extent.Text}
$reportBlock=[scriptblock]::Create(($prefix -join "`n")+"`nreturn `$rows.ToArray()")
$reportRows=@(& $reportBlock)
$reportFeb=($reportRows|Where-Object Month -eq 'fev/2027').Total;$realFeb=Get-ContagemInstitucionalAprovadaMes 2027 2
if($reportFeb -ne 2 -or $realFeb -ne 1){throw 'A03 nao reproduzido'}
Finding A03 "Fevereiro: relatorio aceites=$reportFeb; Central=$realFeb; datas sem sobreposicao" 'Mesma equivalencia institucional em ambas as visoes' 'Calculo original do relatorio executado ate montar rows, sem gerar HTML'
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-04-01';$script:Records=@($r)
$f=[pscustomobject]@{Ano=2027;Mes=0;Situacao='SOMENTE CRÍTICAS';Busca='';Sobreposicao=$false}
$m=Get-PlanejamentoViewModel $f
if($m.Linhas.Count -ne 1 -or $m.Criticos.Count){throw 'A04 nao reproduzido'}
Finding A04 'Filtro SOMENTE CRITICAS devolveu 1 linha sem qualquer mes critico' 'Zero linhas' 'continue interno ao switch nao avanca o foreach externo'
$r2=New-Record 2 'TESTE2';$r2.opcao1=New-Common '2027-04-01';$script:Records=@($r,$r2)
$overlap=Get-PlanejamentoOverlapInfo 'A' 'DIURNO' 2027 4
$f.Situacao='TODAS AS LINHAS';$f.Sobreposicao=$true;$m=Get-PlanejamentoViewModel $f
if($overlap.pico -ne 2 -or $m.Linhas.Count -ne 0){throw 'A05 nao reproduzido'}
Finding A05 'Pico real=2, mas filtro de sobreposicao devolve zero linhas' 'Linha A/DIURNO incluida' 'Get-EstadoLinhaPlanejamento retorna sobreposicao=false constante'
# Use actual reset-backup selector with an in-memory directory listing.
$script:BackupDir='/CAMINHO_SINTETICO';$script:Restored=''
function Get-ChildItem {param($LiteralPath,$Filter,[switch]$File,$ErrorAction)@([pscustomobject]@{Name='ANTES_RESET_TOTAL_REAL_20261018_100000_000.json';FullName='/antigo.json'},[pscustomobject]@{Name='ANTES_RESET_DECISOES_20261020_100000_000.json';FullName='/recente.json'})}
function Restore-DatabaseSafely {param($SourcePath,$BackupReason,$OperationName)$script:Restored=$SourcePath;return $true}
Restaurar-UltimoPreReset|Out-Null
Remove-Item Function:Get-ChildItem
if($script:Restored -ne '/antigo.json'){throw 'A06 nao reproduzido'}
Finding A06 $script:Restored '/recente.json' 'Funcao real escolheu TOTAL mais antigo pela ordem alfabetica do prefixo'
Reset-Fixture
$script:Config.total_enfermeiros_planejamento=189
$numTotalEnf=[pscustomobject]@{Value=200};$numPctRestrito=[pscustomobject]@{Value=10}
$script:chkMesRestrito=@();$script:numLimiteEspecialMes=@()
foreach($month in 1..12){$script:chkMesRestrito+=,[pscustomobject]@{Checked=($month -eq 1)};$script:numLimiteEspecialMes+=,[pscustomobject]@{Value=0}}
$nomesMesCfg=@('Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez')
$handler=Handler '' '$btnSalvarPoliticaMensal.add_Click('
& $handler
if($script:AuditSaves -ne 0 -or $script:Config.total_enfermeiros_planejamento -ne 200){throw 'A07 nao reproduzido'}
Finding A07 'Validacao rejeitou mes com limite zero; Save nao executou; Config em memoria mudou de 189 para 200' 'Configuracao permanecer igual quando validacao falha' 'Handler real executado com controles sinteticos'
Reset-Fixture
$script:tabsPrincipal=[pscustomobject]@{SelectedTab='plano'};$script:tabPlanejamentoPrincipal='plano'
$rows=[pscustomobject]@{};$rows|Add-Member ScriptMethod Clear {}
$cell=[pscustomobject]@{Value='REAL ANTERIOR';ToolTipText='anterior'}
$script:gridPlanejSetor=[pscustomobject]@{Enabled=$false;Rows=$rows}
$script:gridLimiteInstitucional=[pscustomobject]@{Enabled=$false;Rows=@([pscustomobject]@{Cells=@($cell)})}
$script:lblPlanejResumo=[pscustomobject]@{Text=''};$script:cmbPlanejAno=[pscustomobject]@{SelectedItem=2027}
$script:PlanejAsync=@{Ready=[pscustomobject]@{Key='anterior'}}
$script:InstitutionalResumoCacheKey="2027|0|189|sintetico"
Set-PlanejamentoUiFalha 'falha de teste'
Refresh-LimiteInstitucionalResumo ([pscustomobject]@{Meses=@{}})
if($null -ne $cell.Value -or -not $script:gridLimiteInstitucional.Enabled){throw 'A08 nao reproduzido'}
Finding A08 'Falha limpou faixa; nova renderizacao com mesma chave retornou sem preencher' 'Faixa institucional reconstruida apos recuperar falha' 'Set-PlanejamentoUiFalha nao invalida InstitutionalResumoCacheKey'
Reset-Fixture
$r=New-Record;$r.opcao1=New-Common '2027-01-01';$r.opcao_aprovada=1
$r.opcao1.fr_inicio='2027-06-01';$r.opcao1.fr_fim='2027-06-20'
$r.opcao2=New-Common '2027-03-01';$r.opcao2.fr_inicio='2027-08-01';$r.opcao2.fr_fim='2027-08-20';$r.fr_opcao_aprovada=2
$mapBlocks=@(Get-OptionBlocks $r ([int]$r.opcao_aprovada));$planned=@(Get-OptionBlocksPlanejamento $r)
if(@($mapBlocks|Where-Object {$_.inicio.Month -eq 8}).Count -ne 0 -or @($planned|Where-Object {$_.inicio.Month -eq 8}).Count -ne 1){throw 'A09 nao reproduzido'}
Finding A09 'Caminho do mapa OPCAO DEFINIDA usa comum=1 e mostra FR de junho; FR aprovada=2 e agosto fica de fora' 'Considerar comum e FR aprovadas independentemente' 'Get-OptionBlocks com indice comum reproduz caminho de Refresh-Dashboard; WinForms nao executado'
# Acquisition correction validates choices but never validates the existing fixed dates.
Reset-Fixture
$r=New-Record;$r.ferias_bloqueadas=$true;$r.fixo_inicio='2027-01-01';$r.fixo_fim='2027-01-15';$script:Records=@($r)
$id=1;$antIni=$r.aquisitivo_inicio;$antFim=$r.aquisitivo_fim
$ini=[pscustomobject]@{Value=[datetime]::new(2027,1,1)};$fim=[pscustomobject]@{Value=[datetime]::new(2027,12,31)};$mot=[pscustomobject]@{Text='Correcao ficticia'}
$dlg=[pscustomobject]@{Tag=$null;DialogResult=[Windows.Forms.DialogResult]::None};$dlg|Add-Member ScriptMethod Close {}
$handler=Handler 'Corrigir-PeriodoSelecionado' '$ok.add_Click('
& $handler
if($null -eq $dlg.Tag -or $dlg.Tag.fim -ne '2027-12-31'){throw 'A10 nao reproduzido'}
Finding A10 'Handler aceitou aquisitivo ate 31/12/2027 mantendo fixa em 01/01/2027' 'Conferir fixa contra novo fim aquisitivo antes de confirmar' 'Validacao real do dialogo com controles e MessageBox sinteticos'
# Structural validator currently accepts decisions with no option/dates.
Reset-Fixture
$r=New-Record;$r.opcao_aprovada=1
$db=[pscustomobject]@{configuracoes=$script:Config;registros=@($r);historico_ferias=@()}
Assert-DatabaseStructure $db
Finding A11 'Base com opcao_aprovada=1 e opcao1 totalmente vazia passou pela validacao estrutural' 'Validacao semantica distinta antes de considerar base integra' 'Assert-DatabaseStructure real; nao demonstra que interface cria esse estado'
$results|ConvertTo-Json -Depth 8|Set-Content "$root/achados_reproduzidos.json" -Encoding utf8
$results|Select-Object id,observado|Format-Table -Wrap
"TOTAL: $($results.Count) reproducoes confirmadas. Nenhuma base real aberta/salva."
